#ifndef BOOLS_H
#define BOOLS_H

#include <jni.h>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>

bool isESP = false;

bool EspLine2 = false;

bool isPlayerName = false;

bool isPlayerDist = false;

bool isPlayerHealth = false;

bool isTeamMateShow = false;

bool EspVidaDraw = false;

bool isPlayer360 = false;

bool isPlayerDistance = false;

bool isCrosshair = false;

bool isDrawCircle = false;

bool isPlayerCount = false;

bool EspRandomColor = false;

Color LineColor = Color::White();

Color ColorBot = Color::White();

Color changecolor = Color::White();

Color LineColorPreto = Color::White();

Color CrossColor = Color::White();

Color CircleColor = Color::White();

Color KnockColor = Color::White();

Color MocoColor = Color::White();

Color BoxColor = Color::White();

Color SkeletonColor = Color::White();

float largura1 = 1280;
float altura1 = 720;
float largura2 = 1920;
float altura2 = 1080;
float largura3 = 2340;
float altura3 = 1080;
float linex = 0;

float liney = 0;

float CrossSize = 50;

float textsize = 5;

float CircleSize = 10;

float linesize = 2;

int boxsize = 2;

float mocosize = 10;

#endif
