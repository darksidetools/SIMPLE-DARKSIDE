# Features

### Affile Cipher


### Linear Congruential Random Generating