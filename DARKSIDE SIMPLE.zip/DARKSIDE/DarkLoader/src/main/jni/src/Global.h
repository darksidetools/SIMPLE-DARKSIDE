#ifndef ANDROID_MOD_MENU_GLOBAL_H
#define ANDROID_MOD_MENU_GLOBAL_H

struct {

	
    uintptr_t MainCameraTransform = 0x5C;  // ATUALIZADO 1.60.1
	uintptr_t Dictionary = 0x44; // ATUALIZADO 1.60.1
	uintptr_t HeadTF = 0x1BC; // ATUALIZADO 1.60.1
	uintptr_t HipTF = 0x1C0; // ATUALIZADO 1.60.1
	uintptr_t ToeTF = 0x1D0; //protected Transform `}Klj; 1.60
	uintptr_t GetToePosition = 0x1D0; // ATUALIZADO 1.60.1
	uintptr_t GetPedireitoPosition = 0x1D4; // ATUALIZADO 1.60.1
	uintptr_t GetPeesqueroPosition = 0x1D8; // ATUALIZADO 1.60.1
	uintptr_t GetMaoDireitaPosition = 0x1E8; // ATUALIZADO 1.0.1
	uintptr_t getMaoEsquerdaPosition = 0x1EC; // ATUALIZADO 1.60.1
	uintptr_t getSholderPosition = 0x1E0; //ATUALIZADO 1.60.1
    uintptr_t IsClientBot = 0xD0; // ATUALIZADO 1.60.1
	uintptr_t U3DStr = 0x251E13C; // ATUALIZADO 1.60.1
    uintptr_t Component_GetTransform = 0x2A88704; // ATUALIZADO 1.60.1
    uintptr_t Transform_INTERNAL_GetPosition = 0x2CEA400; // ATUALIZADO 1.60.1
    uintptr_t Transform_INTERNAL_SetPosition = 0x2CEA4C0; // ATUALIZADO 1.60.1
    uintptr_t GetForward = 0x2CEAAE4; // ATUALIZADO 1.60.1
    uintptr_t get_isAlive = 0x1F38668; // ATUALIZADO 1.60.1
    uintptr_t GetPhysXPose = 0x9FDB60; // ATUALIZADO 1.60.1
    uintptr_t IsFiring = 0x9EC748; // ATUALIZADO 1.60.1
    uintptr_t get_IsCrouching = 0x9FDB94; // ATUALIZADO 1.60.1
    uintptr_t get_IsSighting = 0xA52DC4; // ATUALIZADO 1.60.1
    uintptr_t get_isLocalTeam = 0x9FBE3C; // ATUALIZADO 1.60.1
    uintptr_t get_isVisible = 0x9F4F48; // ATUALIZADO 1.60.1
    uintptr_t set_aim = 0x9F2A0C; // ATUALIZADO 1.60.1
    uintptr_t Camera_main_fov = 0x2A83C30; // ATUALIZADO 1.60.1
    uintptr_t get_imo = 0x9F82F0; // ATUALIZADO 1.60.1
    uintptr_t set_esp = 0x1AF864C; // ATUALIZADO 1.60.1
    uintptr_t GetAttackableCenterWS = 0x9F11A4; // ATUALIZADO 1.60.1
    uintptr_t get_NickName = 0x9F16C4; // ATUALIZADO 1.60.1
    uintptr_t WorldToScreenPoint = 0x2A855A0; // ATUALIZADO 1.60.1
    uintptr_t get_height = 0x2CDF064; // ATUALIZADO 1.60.1
    uintptr_t get_width = 0x2CDEFD4; // ATUALIZADO 1.60.1
	uintptr_t set_height = 0x2A82DB0; // ATUALIZADO 1.60.1
    uintptr_t CurrentUIScene = 0x1774488; // ATUALIZADO 1.60.1
    uintptr_t Curent_Match = 0x1775074; // ATUALIZADO 1.60.1
    uintptr_t Current_Local_Player = 0x17753C8; // ATUALIZADO 1.60.1
    uintptr_t GetLocalPlayerOrObServer = 0x17768D0; // ATUALIZADO 1.60.1
    uintptr_t CurrentLocalSpectator = 0x1775848; // ATUALIZADO 1.60.1
    uintptr_t AddTeammateHud = 0xCC91AC; //	ATUALIZAD 1.60.1
    uintptr_t spof_uid = 0x9F15C4; // ATUALIZADO 1.60.1
    uintptr_t spof_nick = 0x9F16CC; // ATUALIZADO 1.60.1
    uintptr_t ShowDynamicPopupMessage = 0xCAEC2C; // ATUALIZADO 1.60.1
    uintptr_t ShowPopupMessage = 0xCAEDA8; // ATUALIZADO 1.60.1
    uintptr_t get_MyFollowCamera = 0x9F2380; // ATUALIZADO 1.60.1
    uintptr_t IsSameTeam = 0x24D8DAC; // ATUALIZADO 1.60.1
    uintptr_t AttackableEntity_GetIsDead = 0x1F3EB5C; // ATUALIZADO 1.60.1
    uintptr_t AttackableEntity_IsVisible = 0x1F3EC84; // ATUALIZADO 1.60.1
    uintptr_t Camera_main = 0x2A85B90; // ATUALIZADO 1.60.1
    uintptr_t get_CurHP = 0xA29968; // ATUALIZADO 1.60.1
    uintptr_t get_IsDieing = 0x9F2288; // ATUALIZADO 1.60.1
    uintptr_t get_IsSkyDiving = 0x9F4240; // ATUALIZADO 1.60.1
    uintptr_t get_IsSkyDashing = 0x9F46D8; // ATUALIZADO 1.60.1
    uintptr_t get_IsParachuting = 0x9F3E38; // ATUALIZADO 1.60.1
    uintptr_t String_Concat = 0x250E9B0; // ATUALIZADO 1.60.1
	uintptr_t RealDead = 0x9F3024; // ATUALIZADO 1.60.1
    uintptr_t IsFemale = 0x9F65B8; //public bool get_IsFemale() { } 1.60
    uintptr_t U3DStrConcat = 0x250E9B0; //public static string Concat(string str0, string str1) { } 1.60
	uintptr_t GetPlayerDead = 0xA29A04; //public int get_MaxHP() { } 1.60
	uintptr_t get_HasHelmet = 0x9F196C; //public bool get_HasHelmet() { } 1.60
    uintptr_t get_HasVest = 0x9F1858; //public bool get_HasVest() { } 1.60
    uintptr_t GetPlayerCaido = 0x9F2288; //public bool get_IsDieing() { } 1.60
	uintptr_t CurHp = 0xA29968; //public int get_CurHP() { } 1.60
	uintptr_t LineRenderer_Set_PositionCount = 0x2C1A298;
    uintptr_t LineRenderer_SetPosition = 0x2C1A338;
    uintptr_t GrenadeLine_DrawLine = 0x1664934;
    //OFFSETS DOS CODS EM HEX NA CPP
    uintptr_t Ghost = 0x2429044; // ATUALIZADO 1.60.1
	uintptr_t NoScope = 0xA2E028; // ATUALIZADO 1.60.1
	uintptr_t Medkit = 0x18637F8; // ATUALIZADO 1.60.1
    uintptr_t Medkit2 = 0xA1CF64; // ATUALIZADO 1.60.1
    uintptr_t MapaHd = 0x2CDA630; // ATUALIZADO 1.60.1
    uintptr_t Speed4x = 0xA2229C; // ATUALIZADO 1.60.1
    uintptr_t RecargaFast = 0x1AE9AE4; // ATUALIZADO 1.60.1
	
	
} Global;

#endif
