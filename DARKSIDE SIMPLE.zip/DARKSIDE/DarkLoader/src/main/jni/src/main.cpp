#include <iostream>
#include <src/Includes/Utils.h>
#include "Hook.h"
#include "Global.h"
#include "Includes/Logger.h"
#include "Includes/obfuscator.hpp"
#include "Canvas/ESP.h"
#include "Canvas/Bools.h"
#include "Canvas/StructsCommon.h"
ESP espOverlay;
#define CR_XD "DarkSide"
#define HOOK(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)
extern "C" {

JNIEXPORT jstring JNICALL
Java_com_Loader_DarkSide_Floatingdarkside_IconWebViewData(
        JNIEnv *env,
        jobject activityObject) {

    return NULL;
}

JNIEXPORT jint JNICALL
Java_com_Loader_DarkSide_Floatingdarkside_IconSize(
        JNIEnv *env,
        jobject activityObject) {
    return 60;
}

JNIEXPORT jobjectArray  JNICALL
Java_com_Loader_DarkSide_Floatingdarkside_getdarkList(
        JNIEnv *env,
        jobject activityObject) {
    jobjectArray ret;

    const char *features[] = {

       "Category_MENU AIMBOT",
       "Toggle_AIMBOT",//0
       "Toggle_AIMBOT FIRE",//1
       "Toggle_AIMBOT SCOPE",//2
       "Toggle_AIMBOT VISIBLE",//4
       "SeekBarSpot_AIM-SPOT_0_3",//5
       "SeekBar_AIM-FOV_0_360",//6
       "Category_MENU ESP",
       "Toggle_ESP FIRE",//9
       "Toggle_ESP GRANADE",
       "Toggle_ESP ALERT",//10
       "Toggle_ESP POPUP",//11
       "Toggle_ESP LINE",//13
       "Toggle_ESP BOX [TEST]",//14
       "Toggle_ESP BOT + DISTANCE",//15
       "Toggle_ESP MOCO",//16
       "Toggle_ESP SKELETON",//17
       "Toggle_ESP KNOCK",//18
       "Toggle_ESP 360°",//20
       "Category_MENU ESP SETUP",
       "Linha_LINE COLOR_0_8",//21
       "Linha_BOX COLOR_0_8",
       "Linha_SKELE COLOR_0_8",
       "Linha_TEXT COLOR_0_8",//22
       "Linha_MOCO COLOR_0_8",//22
       "Linha_KNOCK COLOR_0_8",
       "SeekBar_TEXT SIZE_0_10",
       "SeekBar_MOCO SIZE_0_10",
       "Category_MENU PLAYER",
       "Toggle_FLY HACK",//27
       "Toggle_FLY HEIGHT",
       "SeekBar_SPEED HACK_0_5",//29
       "Toggle_TELEPORT CAR",
       "Toggle_MEDKIT RUN",
	   "Toggle_SPEED FIRE",
       "Toggle_WALLHACK V3",
	   "Toggle_AUTO REVIVE",
        
        
        };
            
            
    int Total_Feature = (sizeof features /
                         sizeof features[0]);

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
}

struct My_Patches {

    MemoryPatch NightMod;
    MemoryPatch modcorHd;
    MemoryPatch MedKitRunning;
    MemoryPatch MedKitRunning2;
    MemoryPatch TeletransportarCarro;
    MemoryPatch fakeName;
    MemoryPatch teleKill;
    MemoryPatch FlyArma;
    MemoryPatch FlyHeight;
    MemoryPatch NoRecoil;
    MemoryPatch Corridinha50x;
    MemoryPatch Speed;
    MemoryPatch Speed2x;
    MemoryPatch Speed3x;
    MemoryPatch Speed4x;
    MemoryPatch Speed5x;
	MemoryPatch SpeedCar;
	MemoryPatch Wallhack;
	MemoryPatch Speedfire;
	
	
    
} BAPANFFpatches;

bool feature1 = false;
bool feature2 = false;
bool feature3 = false;
bool feature4 = false;
bool feature5 = false;
bool feature6 = false;
bool feature7 = false;
bool feature8 = false;
bool feature9 = false;
bool feature10 = false;
float Fov_Aim = 0.998f;
    int semihs = 0;
    bool hs100 = false;
    bool aimFire = false;
    bool aimScope = false;
    bool aimBotFov = false;
    bool hs70 = false;
    bool aimBody = false;
    bool aimAgachado = false;
    bool aimbotauto = false;
    bool espnear = false;
    bool Gravity = false;
    bool espNames = false;
    bool MedKitRunning = false;
    bool MedKitRunning2 = false;
    bool teleKill = false;
    bool ghost = false;
    bool modcorHd = false;
    bool fakeName = false;
    bool espNear = false;
    bool isEspReady = false;
    bool GrenadeLine = false;
    bool espFire = false;
	bool UseFOV = false;
	bool FovCount2 = false;
	bool UseMxD = false;
	bool MxDis = false;
	bool UseScope = false;
	bool UseFiring = false;
bool AimTiro = false;
bool AimMira = false;
bool UseAgachado = false;
bool UseAimFov = false;
bool UseAimFov2 = false;
bool UseCaidos = true;
bool Derrubados = false;
bool AimVisible = false;
bool UseVisible = false;
int aimspot = 0;
float AimFovCount2 = 0;
bool Wall = false;
bool EspAlert = false;
bool EspFire = false;
bool EspM = false;
bool EspLine = false;
bool EspBox = false;
bool EspCross = false;
bool EspMoco = false;
bool ESP360 = false;
bool EspAlvo = false;
bool EspPopup = false;
bool Distancia3 = false;
float largura = 1920;
float altura = 1080;
bool EspEsqueleto = false;
bool EspAliados = false;
bool ESPFPS = false;
bool EspPopup2 = false;
bool removerconta = false;
bool fakename = false;
bool medkit = false;
bool WallPedra = false;
bool Pedra = false;
bool GhostHack = false;
bool modonoite = false;
bool mapahd = false;
bool caidos = false;
bool isbot = false;
bool espsexo = false;
bool espcolete = false;
bool fly = false;
bool off = false;
bool Ghost = false;
bool FlySpeed = false;
bool doublegun = false;
bool speed = false;
bool active = true;
bool FlyHeight = false;
int SpeedInt = 0;
bool NoRecoil = false;
bool Corridinha50x = false;
bool autoRevive = false;
bool Value = false;
bool CarSpeed = false;
bool launched = false;
int m_gSWidth = 1920;
int m_gSHeight = 1080;




JNIEXPORT void JNICALL
Java_com_Loader_DarkSide_Floatingdarkside_Changes(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint value) {

    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Feature: = %d", feature);
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Value: = %d", Value);

    switch (feature) {

   case 1:
           hs100 = !hs100;
           break;
        
   case 2:
           aimFire= !aimFire;
           break;
        
   case 3:
           aimScope= !aimScope;
           break;
   case 4:
           UseVisible = !UseVisible;
           break;
            
   case 5:
        if (value == 0) {
            hs100 = false;
            hs70 = false;
            aimBody = false;
            } else if (value == 1) {
                hs70 = false;
                aimBody = false;
                hs100 = !hs100;
                hs100 = true;
            } else if (value == 2) {
                hs100 = false;
                aimBody = false;
                hs70 = !hs70;
                hs70 = true;
            } else if (value == 3) {
                hs100 = false;
                hs70 = false;
                aimBody = !aimBody;
                aimBody = true;
            }
        break;
		
   case 6:
        if (value > 0) {
            Fov_Aim = 1.0f - (0.0099f * (float)value);
            aimBotFov = 1.0f - (0.0099f * (float)value);
        }
		break;
            
   case 8:
            EspFire = !EspFire;
            break;
            
   case 9:
            GrenadeLine = !GrenadeLine;
            break;
            
   case 10:
            EspAlert = !EspAlert;
            break;
            
   case 11:
            EspPopup2 = !EspPopup2;
            break;
            
   case 12:
            EspLine = !EspLine;
            break;
            
   case 13:
            EspBox = !EspBox;
            break;
            
   case 14:
            espcolete = !espcolete;
            break;
            
   case 15:
            EspMoco = !EspMoco;
            break;
            
   case 16:
            EspEsqueleto = !EspEsqueleto;
            break;
            
   case 17:
            caidos = !caidos;
            break;
   case 18:
            ESP360 = !ESP360;
            break;
            
   case 20:
            if (value == 0 ){
            changecolor = Color::White();
            } else if(value == 1 ){
            changecolor = Color::Green();
            } else if(value == 2 ){
            changecolor = Color::Black();
            } else if(value == 3 ){
            changecolor = Color::Blue();
            } else if(value == 4 ){
            changecolor = Color::Cyan();
            } else if(value == 5 ){
            changecolor = Color::Purple();
            } else if(value == 6 ){
            changecolor = Color::Yellow();
            } else if(value == 7 ){
            changecolor = Color::Red();
            }else if(value == 8 ){
            changecolor = LineColor;
            } 
            break;
   case 21:
            if (value == 0 ){
            BoxColor = Color::White();
            } else if(value == 1 ){
            BoxColor = Color::Green();
            } else if(value == 2 ){
            BoxColor = Color::Black();
            } else if(value == 3 ){
            BoxColor = Color::Blue();
            } else if(value == 4 ){
            BoxColor = Color::Cyan();
            } else if(value == 5 ){
            BoxColor = Color::Purple();
            } else if(value == 6 ){
            BoxColor = Color::Yellow();
            } else if(value == 7 ){
            BoxColor = Color::Red();
            }else if(value == 8 ){
            BoxColor = LineColor;
            }
            break;
            
   case 22: 
            if (value == 0 ){
            SkeletonColor = Color::White();
            } else if(value == 1 ){
            SkeletonColor = Color::Green();
            } else if(value == 2 ){
            SkeletonColor = Color::Black();
            } else if(value == 3 ){
            SkeletonColor = Color::Blue();
            } else if(value == 4 ){
            SkeletonColor = Color::Cyan();
            } else if(value == 5 ){
            SkeletonColor = Color::Purple();
            } else if(value == 6 ){
            SkeletonColor = Color::Yellow();
            } else if(value == 7 ){
            SkeletonColor = Color::Red();
            }else if(value == 8 ){
            SkeletonColor = LineColor;
            } 
            break;
            
   case 23:
            if (value == 0 ){
            ColorBot = Color::White();
            } else if(value == 1 ){
            ColorBot = Color::Green();
            } else if(value == 2 ){
            ColorBot = Color::Black();
            } else if(value == 3 ){
            ColorBot = Color::Blue();
            } else if(value == 4 ){
            ColorBot = Color::Cyan();
            } else if(value == 5 ){
            ColorBot = Color::Purple();
            } else if(value == 6 ){
            ColorBot = Color::Yellow();
            } else if(value == 7 ){
            ColorBot = Color::Red();
            }else if(value == 8 ){
            ColorBot = LineColor;
            } 
            break;
    case 24:
            if (value == 0 ){
            MocoColor = Color::White();
            } else if(value == 1 ){
            MocoColor = Color::Green();
            } else if(value == 2 ){
            MocoColor = Color::Black();
            } else if(value == 3 ){
            MocoColor = Color::Blue();
            } else if(value == 4 ){
            MocoColor = Color::Cyan();
            } else if(value == 5 ){
            MocoColor = Color::Purple();
            } else if(value == 6 ){
            MocoColor = Color::Yellow();
            } else if(value == 7 ){
            MocoColor = Color::Red();
            }else if(value == 8 ){
            MocoColor = LineColor;
            } 
            break;
          
   case 25:
            if (value == 0 ){
            KnockColor = Color::White();
            } else if(value == 1 ){
            KnockColor = Color::Green();
            } else if(value == 2 ){
            KnockColor = Color::Black();
            } else if(value == 3 ){
            KnockColor = Color::Blue();
            } else if(value == 4 ){
            KnockColor = Color::Cyan();
            } else if(value == 5 ){
            KnockColor = Color::Purple();
            } else if(value == 6 ){
            KnockColor = Color::Yellow();
            } else if(value == 7 ){
            KnockColor = Color::Red();
            }else if(value == 8 ){
            KnockColor = LineColor;
            } 
            break;
            
   case 26:
            if (value == 0 ){
            textsize = value = 2;
            } else if(value == 1 ){
            textsize = value = 4;
            } else if(value == 2 ){
            textsize = value = 6;
            } else if(value == 3 ){
            textsize = value = 8;
            } else if(value == 4 ){
            textsize = value = 10;
            } else if(value == 5 ){
            textsize = value = 12;
            } else if(value == 6 ){
            textsize = value = 14;
            } else if(value == 7 ){
            textsize = value = 16;
            } else if(value == 8 ){
            textsize = value = 18;
            } else if(value == 9 ){
            textsize = value = 20;
            } else if(value == 10 ){
            textsize = value = 22;
            }
            break;
            
   case 27:
            if (value == 0 ){
            mocosize = value = 10;
            } else if(value == 1 ){
            mocosize = value = 15;
            } else if(value == 2 ){
            mocosize = value = 20;
            } else if(value == 3 ){
            mocosize = value = 25;
            } else if(value == 4 ){
            mocosize = value = 30;
            } else if(value == 5 ){
            mocosize = value = 35;
            } else if(value == 6 ){
            mocosize = value = 40;
            } else if(value == 7 ){
            mocosize = value = 45;
            } else if(value == 8 ){
            mocosize = value = 50;
            } else if(value == 9 ){
            mocosize = value = 55;
            } else if(value == 10 ){
            mocosize = value = 60;
            }
            break;
            
   case 29:
            Gravity = !Gravity;
            feature5 = !feature5;
            if (feature5) {
            BAPANFFpatches.NoRecoil.Modify();
            } else {
            BAPANFFpatches.NoRecoil.Restore();
		    }
            break;
   case 30: 
            FlyHeight = !FlyHeight;
            ghost = !ghost;
            break;
            
   case 31:
            if (value == 0) {
            BAPANFFpatches.Speed.Restore();
            } else if (value == 1) {
            BAPANFFpatches.Speed2x.Modify();
            } else if (value == 2) {
            BAPANFFpatches.Speed3x.Modify();
            } else if (value == 3) {
            BAPANFFpatches.Speed4x.Modify();
            } else if (value == 4) {
            BAPANFFpatches.Speed5x.Modify();
            } else if (value == 5) {
            BAPANFFpatches.Speed5x.Modify();
            }
            break;
		
   case 32:
            feature4 = !feature4;
            if (feature4) {
            BAPANFFpatches.TeletransportarCarro.Modify();
            } else {
            BAPANFFpatches.TeletransportarCarro.Restore();
            }
            break;
   case 33:
            feature1 = !feature1;
            if (feature1) {
                BAPANFFpatches.MedKitRunning.Modify();
                BAPANFFpatches.MedKitRunning2.Modify();
            } else {
                BAPANFFpatches.MedKitRunning.Restore();
                BAPANFFpatches.MedKitRunning2.Restore();
            }
            break;
			
   case 34:
	        feature10 = !feature10;
		    if (feature10) {
		    BAPANFFpatches.Speedfire.Modify();
			} else {
			BAPANFFpatches.Speedfire.Restore();
			}
			break;
			
   case 35: 
            feature6 = !feature6;
            if (feature6) {
                BAPANFFpatches.Wallhack.Modify();
            } else {
                BAPANFFpatches.Wallhack.Restore();
            }
            break;
			
    case 36:
		     autoRevive = !autoRevive;
		     break;
            
    
        
       }
     }
   }

struct EnemyData {
    monoString * Name;
    bool isSameTeam;
    bool isCaido;
    bool isBot;
    bool isLocalPlayer;
    bool capa;
    bool colete;
    int Health;
    bool PlayerFeminino;
    int vida;
    string Name4;
    float Distance3;
    Vector3 Location;
    Vector3 HeadLocation;
    Vector3 PlayerHead;
    Vector3 Pe;
    Vector3 Hip;
    Vector3 MaoDireita;
    Vector3 PeDireito;
    Vector3 PeEsquerdo;
    Vector3 Sholder1;
	Vector3 Sholder2;
    Vector2 HeadLocation2;
    Vector2 Location2;
    Vector3 Pescoco;
    Vector3 MaoEsquerda;
};

struct Response {
    int PlayerCount;
    EnemyData Players[maxplayerCount];
};

struct {
    bool EspReady;
} XDark;

void* UIInGameScene = NULL;
Vector3 GetHeadPosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.HeadTF));
}
Vector3 GetToePosition (void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.ToeTF));
}
Vector3 GetHipPosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.HipTF));
}
Vector3 GetPedireitoPosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + 0x1D0));
}
Vector3 GetPeEsquerdoPosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + 0x1E0));
}
Vector3 GetMaoDireitaPosition(void *player) {
    return Transform_INTERNAL_GetPosition(
            *(void **) ((uint64_t) player + 0x1E8));
}
Vector3 getMaoEsquerdaPosition(void *player) {
    return Transform_INTERNAL_GetPosition(
            *(void **) ((uint64_t) player + 0x1B8));
}
Vector3 getPescocoPosition(void *player) {
    return Transform_INTERNAL_GetPosition(
            *(void **) ((uint64_t) player + 0x1C4));
}
Vector3 getSholder1Position(void *player) {
    return Transform_INTERNAL_GetPosition(
            *(void **) ((uint64_t) player + 0x1EC));
}
Vector3 getSholder2Position(void *player) {
    return Transform_INTERNAL_GetPosition(
            *(void **) ((uint64_t) player + 0x1F0));
}
static void SetColor(Color CurColor) {
    void (*_SetColor)(Color _Colors) = (void (*)(Color))getRealOffset(0x2CDA94C); //public static void set_fogColor(Color value) { } 1.60
    _SetColor(CurColor);
}

void *Grenade2 = NULL;

void *Render2 = NULL;

void (*_GrenadeLine_Update)(void *instance);
void GrenadeLine_Update(void *instance) {
    if (instance != NULL) {
        Grenade2 = instance;
        *(bool *)((uintptr_t)instance + 0xC) = true;
        Render2 = *(void **)((long)instance + 0x10);
    }
    _GrenadeLine_Update(instance);
}

static void* PlayerCollider(void* This) {
    void *(*Player_HeadCollider)(void * _this) = (void *(*)(void *))getRealOffset(0x9F24C0);
    return Player_HeadCollider(This);
}


static void* GetGameObject(void* This) {
    void* (*Component_get_gameObject)(void *_this) = (void*(*)(void *))getRealOffset(0x2A88870);
    return Component_get_gameObject(This);
}


static int GetLayerOb(void *This) {
    int (*GameObject_get_layer)(void * _this) = (int (*)(void *))getRealOffset(0x2B65338);
    return GameObject_get_layer(This);
}

typedef struct RayCastHit {
    Vector3 m_Point; 
    Vector3 m_Normal;
    int m_FaceID; 
    float m_Distance; 
    Vector2 m_UV; 
    void *m_Collider;
};

static bool Physics_Raycast(void *pt, Vector3 orig, Vector3 Direct, RayCastHit *hitInform, float mxDistance) {
bool (*_Physics_Raycast)(void * ptr, Vector3 origin, Vector3 direction, RayCastHit *hitInfo, float maxDistance) = (bool (*)(void *, Vector3, Vector3, RayCastHit *, float))getRealOffset(0x2C2BF7C);
  return _Physics_Raycast(pt, orig, Direct, hitInform, mxDistance);
}

bool TargetVisible(void *LocalPlayer,void *EnemyPlayer)
{
    RayCastHit hit;
    Vector3  target = Transform_INTERNAL_GetPosition(Component_GetTransform(PlayerCollider(EnemyPlayer)));
    Vector3 camera = Transform_INTERNAL_GetPosition(Component_GetTransform(PlayerCollider(LocalPlayer)));
    Vector3 targetDir = target - camera;
    if (Physics_Raycast(NULL, camera, targetDir, &hit, Vector3::Distance(camera, target)))
    {
        void *hitObject = GetGameObject(hit.m_Collider);
        void *enemyObject = GetGameObject(PlayerCollider(EnemyPlayer));
        int layer = GetLayerOb(hitObject);
        int layerHead = GetLayerOb(enemyObject);
        Vector3 Point = hit.m_Point;
        Vector3 NormalizedCast = hit.m_Normal;
        int FaceId = hit.m_FaceID;
        float LayerDist = hit.m_Distance;
        Vector2 layerUV = hit.m_UV;
        if ((layer == 28 || layer == 13) && layerHead == 13) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

Vector3 LookHeadPos = Vector3();


void (*LateUpdate)(void *componentPlayer);
void AimBot(void *local_player, void *enemy_player) {
                            
    int pose = GetPhysXPose(enemy_player);
    bool alive = get_isAlive(enemy_player);
    bool visible = get_isVisible(enemy_player);
    bool visi = get_AttackableEntity_IsVisible(enemy_player);
    bool visir = get_AttackableEntity_GetIsDead(enemy_player);
	

    bool sameteam = get_isLocalTeam(enemy_player);
    void *HeadTF = *(void **)((uintptr_t)enemy_player + Global.HeadTF);
    void *HipTF = *(void **)((uintptr_t)enemy_player + Global.HipTF);
    void *Main_Camera = *(void **)((uintptr_t)local_player + Global.MainCameraTransform);
    void* CurrentWP = get_imo(local_player);

    if (alive && pose != 8  && visible && !sameteam && HeadTF != NULL && Main_Camera != NULL && HipTF != NULL) {
        Vector3 EnemyLocation = Transform_INTERNAL_GetPosition(HeadTF);
        Vector3 CenterWS = GetAttackableCenterWS(local_player);
        Vector3 CurTF = GetHipPosition(local_player);
        Vector3 CurEnTF = GetHipPosition(enemy_player);
		bool RealMorte = GetPlayerDead(local_player);
		bool agachado = get_IsCrouching(local_player);
        bool scope = get_IsSighting(local_player);
		bool EnemyVisible = TargetVisible(local_player,enemy_player);
        float distance = Vector3::Distance(CenterWS, EnemyLocation);

        Vector3 PlayerLocation = Transform_INTERNAL_GetPosition(Main_Camera);
        Quaternion PlayerLook = GetRotationToLocation(EnemyLocation, 0.1f, PlayerLocation);
        Quaternion PlayerLook2 = GetRotationToLocation(Transform_INTERNAL_GetPosition(HipTF), 0.1f, PlayerLocation);
                Vector3 fwd = GetForward(Main_Camera);
                
        Vector3 nrml = Vector3::Normalized(EnemyLocation - PlayerLocation);
        float PlayerDot = Vector3::Dot(fwd, nrml);
		
		
                    if(GrenadeLine && !UseVisible || EnemyVisible) {
                        Vector3 To = GetHeadPosition(local_player);
                        GrenadeLine_DrawLine(Grenade2, To, EnemyLocation, Vector3(0,1,0) * 0.6);
                        if (Render2) {
                        LineRenderer_Set_PositionCount(Render2, 0x2);
                        LineRenderer_SetPosition(Render2, 0, To);
                        LineRenderer_SetPosition(Render2, 1, EnemyLocation);
                    }
                 }

        if(EspAlert) {
            void *ui = CurrentUIScene();
            if (ui != NULL) {
                monoString *nick = get_NickName(enemy_player);
                monoString *distances = U3DStrFormat(distance);
                AddTeammateHud(ui, nick, distances);
            }
        }
        if(EspPopup) {
            void *ui = CurrentUIScene();
            if (ui != NULL) {
                monoString *nick = get_NickName(enemy_player);
                ShowPopupMessage2(nick);
            }
        }
        if(EspPopup2) {
            void *ui = CurrentUIScene();
            if (ui != NULL) {
                monoString *nick = get_NickName(enemy_player);
                ShowPopupMessage3(nick);
            }
        }

        if(fakename) {
            void *ui = CurrentUIScene();
            if (ui != NULL) {
                spofNick(local_player);
            }
        }

    
        void* CurrentWP = get_imo(local_player);

        if(EspM) {
            //int SxWidth = Screen_get_width();
            Vector3 From = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main()));
            Vector3 BodyZPos = GetHipPosition(local_player);
            Vector3 From2 = From + Vector3(2.3,8,(BodyZPos.Z - From.Z));
            Vector3 To = GetHeadPosition(enemy_player);
            set_esp(CurrentWP,From2,To);
        }
        
        if (teleKill) {
                   void *_MountTF = Component_GetTransform(enemy_player);
                   if (_MountTF != NULL) {
                   Vector3 MountTF =
                   Transform_INTERNAL_GetPosition(_MountTF) -
                   (GetForward(_MountTF) * 1.6f);
                   Transform_INTERNAL_SetPosition(Component_GetTransform(local_player),
                                                           Vvector3(MountTF.X, MountTF.Y,
                                                                    MountTF.Z));
                   }
                  }

        if (EspFire) {
            void *imo = get_imo(local_player);
            if (imo != NULL && distance <= 150.0f) {
                set_esp(imo, CenterWS,  EnemyLocation);
            }
        }
        
            if ((agachado && aimAgachado) && ((PlayerDot > 0.998f && !aimBotFov) || (PlayerDot > Fov_Aim && aimBotFov && !UseVisible || UseVisible && EnemyVisible))) {
            set_aim(local_player, PlayerLook);
        }
       

        if ((scope && aimScope) && ((PlayerDot > 0.998f && !aimBotFov) || (PlayerDot > Fov_Aim && aimBotFov && !UseVisible || UseVisible && EnemyVisible))) {
           set_aim(local_player, PlayerLook);

        }
        

         bool firing = IsFiring(local_player);
        if ((firing && aimFire) && ((PlayerDot > 0.998f && !aimBotFov) || (PlayerDot > Fov_Aim && aimBotFov && !UseVisible || UseVisible && EnemyVisible))) {
                        

            if (aimBody && !UseVisible || UseVisible && EnemyVisible) {
                set_aim(local_player, PlayerLook2);
            }
            if (hs100 && !UseVisible || UseVisible && EnemyVisible) {
                set_aim(local_player, PlayerLook);
            }
            if (hs70 && !UseVisible || UseVisible && EnemyVisible) {
                if (aimbotauto)
                {
                    set_aim(local_player, PlayerLook);
                    ++semihs;
                } else {
                    set_aim(local_player, PlayerLook2);
                    --semihs;
                }

                if (semihs == 6)
                {
                    aimbotauto = false;
                } else if (semihs == 0) {
                    aimbotauto = true;
                }
                if (semihs > 6 || semihs < 0)
                {
                    semihs = 3;
                    aimbotauto = true;
		   
                }
             }
          }
       }
    }
 
Response response{};
void createDataList(void* Enemy, void* LocalPlayer) {
    /// posiçao player,etc
    void* MainCam = Camera_main();
    Vector3 CamPos = Transform_INTERNAL_GetPosition(Component_GetTransform(MainCam));
    Vector3 EnemyPos = GetHipPosition(Enemy);
    Vector2 BoxToScreen = WorldLocToScreenPoint2(Camera_main(),EnemyPos);
    float DistanceBox = (Vector2::Distance(BoxToScreen,Vector2(CamPos.X,CamPos.Y)) / 100.0f);

    /// posicao para desenhar
    Vector3 HeadPos = WorldLocToScreenPoint(Camera_main(),GetHeadPosition(Enemy));
    Vector3 HeadLocalPlayer = WorldLocToScreenPoint(Camera_main(),GetHeadPosition(LocalPlayer));
    Vector2 HeadPos2 = WorldLocToScreenPoint2(Camera_main(),GetHeadPosition(Enemy));
    Vector3 Pe = WorldLocToScreenPoint(Camera_main(),GetToePosition(Enemy));
    Vector3 Hip = WorldLocToScreenPoint(Camera_main(),GetHipPosition(Enemy));
    Vector3 Pedireitoo = WorldLocToScreenPoint(Camera_main(),GetPedireitoPosition(Enemy));
    Vector3 PeEsquerdoo = WorldLocToScreenPoint(Camera_main(),GetPeEsquerdoPosition(Enemy));
    Vector3 MaoDireitaa = WorldLocToScreenPoint(Camera_main(),GetMaoDireitaPosition(Enemy));
    Vector3 MaoEsquerda = WorldLocToScreenPoint(Camera_main(),getMaoEsquerdaPosition(Enemy));
    Vector3 Pescoco = WorldLocToScreenPoint(Camera_main(),getPescocoPosition(Enemy));
    Vector3 Ombro1 = WorldLocToScreenPoint(Camera_main(),getSholder1Position(Enemy));
    Vector3 Ombro2 = WorldLocToScreenPoint(Camera_main(),getSholder2Position(Enemy));

    ///distancia
    float distance3 = Vector3::Distance(CamPos,GetHipPosition(Enemy));

///booleans
    bool isSameTeamm = get_isLocalTeam(Enemy);
    bool isPlayerCaido = GetPlayerCaido(Enemy);
    bool isPlayerBot = *(bool*)((uintptr_t)Enemy + Global.IsClientBot);
    bool Capacete = TemCapacete(Enemy);
    bool Colete = TemColete(Enemy);
    bool isFemea = IsFemale(Enemy);
  //  int health = CurHp(Enemy);

    EnemyData* data = &response.Players[response.PlayerCount];
    data->Distance3 = distance3;
    data->Location = CamPos;
    data->Pe = Pe;
    data->HeadLocation2 = HeadPos2;
    data->PlayerHead = HeadLocalPlayer;
    data->Hip = Hip;
    data->isSameTeam = isSameTeamm;
    data->isCaido = isPlayerCaido;
    data->isBot = isPlayerBot;
    data->capa = Capacete;
    data->colete = Colete;
    data->PlayerFeminino = isFemea;
    data->MaoDireita = MaoDireitaa;
    data->PeDireito = Pedireitoo;
    data->PeEsquerdo = PeEsquerdoo;
    data->MaoEsquerda = MaoEsquerda;
	data->Sholder1 = Ombro1;
	data->Sholder2 = Ombro2;
    data->Pescoco = Pescoco;
    data->HeadLocation = HeadPos;
    if (Enemy != LocalPlayer) {
    data->isLocalPlayer = false;
    ++response.PlayerCount;

      }
   }

void *fakeEnemy;
void _LateUpdate(void *player){
    if (player != NULL) {
        void *local_player = Current_Local_Player();
        if (local_player == NULL){
            local_player = GetLocalPlayerOrObServer();
        }
        if (local_player != NULL){
            void *current_match = Curent_Match();
            if (current_match != NULL) {
				isEspReady = false;
                void *fakeCamPlayer = get_MyFollowCamera(local_player);
                void *fakeCamEnemy = get_MyFollowCamera(player);
                if (fakeCamPlayer != NULL && fakeCamEnemy != NULL){
                    void *fakeCamPlayerTF = Component_GetTransform(fakeCamPlayer);
                    void *fakeCamEnemyTF = Component_GetTransform(player);
                    if (fakeCamPlayerTF != NULL && fakeCamEnemyTF != NULL){
                        Vector3 fakeCamPlayerPos = Transform_INTERNAL_GetPosition(fakeCamPlayerTF);
                        Vector3 fakeCamEnemyPos = Transform_INTERNAL_GetPosition(fakeCamEnemyTF);
                        float distance = Vector3::Distance(fakeCamPlayerPos, fakeCamEnemyPos);
                        if (player != local_player){
                            if (distance > 1.6f) {
                                bool sameteams = get_isLocalTeam(player);
                                int pose = GetPhysXPose(player);
                                bool alive = get_isAlive(player);
                                bool visible = get_isVisible(player);
                                bool visir = get_AttackableEntity_GetIsDead(player);
                                       
                                if (!sameteams && pose != 8 && alive && visible){
                                    AimBot(local_player, player);
                                }
                            } else {
                                fakeEnemy = player;
                            }
                        }
                    }
                    if(!isEspReady) {
                        XDark.EspReady = false;
                        response.PlayerCount = 1;
                        m_gSWidth = XsWidth();
                        m_gSHeight = XsHeight();
                        monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)current_match + 0x44);
                        for(int u = 0; u < players->getNumValues(); u++)
                        {
                            void* closestEnemy = players->getValues()[u];
                            if (closestEnemy != local_player && closestEnemy != NULL && get_isVisible(closestEnemy) && !AttackableEntity_GetIsDead(closestEnemy)) {
                                createDataList(closestEnemy,local_player);
                            }

                        }
                        isEspReady = true;
                        XDark.EspReady = true;

                    }

                }
            }
        }
    }
    LateUpdate(player);
}

                
              
int isOutsideSafezone(Vector2 pos, Vector2 screen) {
    Vector2 mSafezoneTopLeft(screen.X * 0.04f, screen.Y * 0.04f);
    Vector2 mSafezoneBottomRight(screen.X * 0.96f, screen.Y * 0.96f);

    int result = 0;
    if (pos.Y < mSafezoneTopLeft.Y) {
        result |= 1;
    }
    if (pos.X > mSafezoneBottomRight.X) {
        result |= 2;
    }
    if (pos.Y > mSafezoneBottomRight.Y) {
        result |= 4;
    }
    if (pos.X < mSafezoneTopLeft.X) {
        result |= 8;
    }
    return result;
}

Vector2 pushToScreenBorder(Vector2 Pos, Vector2 screen, int borders, int offset) {
    int x = (int)Pos.X;
    int y = (int)Pos.Y;
    if ((borders & 1) == 1) {
        y = 0 - offset;
    }
    if ((borders & 2) == 2) {
        x = (int)screen.X + offset;
    }
    if ((borders & 4) == 4) {
        y = (int)screen.Y + offset;
    }
    if ((borders & 8) == 8) {
        x = 0 - offset;
    }
    return Vector2(x, y);
}

void DrawESP(ESP esp, int screenWidth, int screenHeight) {

    int count = response.PlayerCount;
    int count2 = count - 2;
    int max;
    max = 255;            
    int max2;
    max2 = 255;            
    int max3;
    max3 = 255;
    if (count >= 0) {
        for (int i = 1; i < count; i++) {
              if (response.Players[i].HeadLocation.Z < -1) continue;
            EnemyData player = response.Players[i];
            EnemyData closest = response.Players[3];
            Vector3 alvo = closest.HeadLocation;
            Vector3 start = closest.PlayerHead;
            Vector3 HeadLoc =response.Players[i].HeadLocation;
            Vector2 HeadLoc2 = response.Players[i].HeadLocation2;
            Vector3 Pee = response.Players[i].Pe;
            Vector3 Hip = response.Players[i].Hip;;
            Vector3 PeDireito = response.Players[i].PeDireito;
			Vector3 Sholder1 = response.Players[i].Sholder1;
			Vector3 Sholder2 = response.Players[i].Sholder2;
            Vector3 PeEsquerdo = response.Players[i].PeEsquerdo;
            Vector3 MaoDireita = response.Players[i].MaoDireita;
            Vector3 MaoEsquerda = response.Players[i].MaoEsquerda;
            Vector3 Pescoco = response.Players[i].Pescoco;
            float distance3 = player.Distance3;
            float distance8 = player.Distance3;
            Vector2 screen(screenWidth, screenHeight);
            Vector2 screen2(largura1, altura1);
            Vector2 screen3(largura2, altura2);
            Vector2 screen4(largura3, altura3);
            float mScale = screenHeight / (float) 1080;
            float Tamanho = 0.0f;
                                                    
                                            if (distance8 > 10.0f) {
                                                Tamanho = 10.0f;
                                            } else if (distance3 < 20.0f) {
                                                Tamanho = 0.0f;
                                            }

            Vector3 End = HeadLoc;
            Vector3 End2 = Pee;
            float boxHeight = ((screenHeight - End2.Y) - (screenHeight - End.Y));
            float boxWidth = (screenHeight / player.Distance3);
            float boxHeight1 = (largura1 / player.Distance3);
            float boxWidth1 = (altura1 / player.Distance3);
            float boxHeight2 = (largura2 / player.Distance3);
            float boxWidth2 = (altura2 / player.Distance3);
            float boxHeight3 = (largura3 / player.Distance3);
            float boxWidth3 = (altura3 / player.Distance3);
            Rect PlayerRect(End2.X - (boxWidth / 2), (screenHeight - End.Y), boxWidth, boxHeight + Tamanho);
            Rect rectplayer3(largura3 - (largura3 - HeadLoc.X) - 15,
                             altura3 - HeadLoc.Y - 5, boxWidth3, boxHeight3);
            Rect rectplayer2(largura2 - (largura2 - HeadLoc.X) - 15,
                             altura2 - HeadLoc.Y - 5, boxWidth2, boxHeight2);
            Rect rectplayer1(largura1 - (largura1 - HeadLoc.X) - 15,
                             altura1 - HeadLoc.Y - 5, boxWidth1, boxHeight1);
            Rect rectplayer(screenWidth - (screenWidth - Hip.X) - 15,
                             screenHeight - Hip.Y - 5, boxWidth, boxHeight);
            float cabeca = (1080 / player.Distance3) / 8;

            char extra[50];
            char counter[50];
            char name[50];
            char name2[50];
            char name3[50];
            
            if (random) {
            LineColor = Color(rand()%max, rand()%max2, rand()%max3, 255); // COLORES ALEATORIAS LINHA
           }
           
          
                   
            int bordes = isOutsideSafezone(HeadLoc2, screen);
            if (ESP360 && bordes != 0 && !EspRandomColor) {
                if (response.Players[i].Distance3 < 1.5) {
                } else { if (!response.Players[i].isSameTeam && !response.Players[i].isCaido) {
                        sprintf(extra, "[%0.0fm]", response.Players[i].Distance3);
                        Vector2 hintDotRenderPos = pushToScreenBorder(HeadLoc2, screen, bordes,
                                                                      (int) ((mScale * 100) / 3));
                        Vector2 hintTextRenderPos = pushToScreenBorder(HeadLoc2, screen, bordes,
                                                                       -(int) ((mScale * 36)));
                        esp.DrawFilledCircle(Color(255, 0, 0), hintDotRenderPos, (mScale * 100));
                        esp.DrawText(Color(255, 255, 255, 255), extra, hintTextRenderPos, 15); }
                }
            }
            
            
            if (EspMoco) {
                if (response.Players[i].Distance3 < 1.5) {
                } else { if (!response.Players[i].isSameTeam && !response.Players[i].isCaido) {
                        esp.DrawText(MocoColor, "ᐁ",
                                     Vector2((screenWidth - (screenWidth - player.HeadLocation.X) +
                                              linex),
                                             screenHeight - HeadLoc2.Y - 15.0f),
                                     mocosize); }
                }
            }
           
               if (espcolete) {
                if (response.Players[i].Distance3 < 1.5 && response.Players) {
                } else {
                if (!response.Players[i].isSameTeam && response.Players[i].isBot && !response.Players[i].isCaido) {
					sprintf(extra, "[ BOT - %0.0fm ]", response.Players[i].Distance3);
						esp.DrawText(ColorBot, extra,
                                     Vector2((screenWidth - (screenWidth - Pee.X) + 5.0f + linex),
                                             screenHeight - Pee.Y + 15.0f),
                                     textsize);
                                    }
                                 }
                               }
                              
           if (espcolete) {
                if (response.Players[i].Distance3 < 1.5 && response.Players) {
                     } else {
                    if (!response.Players[i].isSameTeam && !response.Players[i].isBot && !response.Players[i].isCaido) {
						sprintf(extra, "[ REAL - %0.0fm ]", response.Players[i].Distance3);
						esp.DrawText(ColorBot, extra,
                                     Vector2((screenWidth - (screenWidth - Pee.X) + 5.0f + linex),
                                             screenHeight - Pee.Y + 15.0f),
                                     textsize);
                       }
                    }
                }
            

            if (caidos) {
                if (response.Players[i].Distance3 < 1.5) {
                }else {if (!response.Players[i].isSameTeam && response.Players[i].isCaido) {
                    
                    esp.DrawLine(KnockColor, linesize, Vector2((screenWidth / 2), 0),
                                     Vector2((screenWidth - (screenWidth - HeadLoc.X) +
                                              linex), screenHeight - HeadLoc.Y - liney)),

                        esp.DrawText(KnockColor, "[ PLAYER - KNOCK ]",
                                     Vector2((screenWidth - (screenWidth - HeadLoc.X) +
                                              linex),
                                             screenHeight - HeadLoc2.Y - 15.0f),
                                     textsize);
                        
                  

                    }
                }
            }
      
              if (Distancia3) {
                if (response.Players[i].Distance3 < 1.5) {
                } else { if (!response.Players[i].isSameTeam && !response.Players[i].isCaido) {
                        sprintf(extra, "[ %.2fm ]", response.Players[i].Distance3);
                        esp.DrawText(ColorBot, extra,
                                     Vector2((screenWidth - (screenWidth - Pee.X) + 5.0f + linex),
                                             screenHeight - Pee.Y + 15.0f), textsize); }
                }
            }
            
              if (EspLine) {
                if (response.Players[i].Distance3 < 1.5) {
                }else { if (!response.Players[i].isSameTeam && !response.Players[i].isCaido) {
                    esp.DrawLine(changecolor, linesize, Vector2((screenWidth / 2), 0),
                                 Vector2((screenWidth - (screenWidth - HeadLoc.X) +
                                          linex), screenHeight - HeadLoc.Y - liney));
                    }
                }
            }
       
          if(EspBox) {
            if (response.Players[i].Distance3 < 1.5) {
            } else { if (!response.Players[i].isSameTeam && !response.Players[i].isCaido && EspBox) {
            esp.DrawBox(Color(BoxColor), boxsize, PlayerRect);
                 }
             }
		  }
            
             if (EspEsqueleto) {
                if (response.Players[i].Distance3 < 1.5) {
                } else { if (!response.Players[i].isSameTeam && !response.Players[i].isCaido) {
                    
                        esp.DrawLine(SkeletonColor, 2,
                                     Vector2((screenWidth - (screenWidth - HeadLoc.X) +
                                              linex), screenHeight - HeadLoc.Y),
                                     Vector2((screenWidth - (screenWidth - Pescoco.X)),
                                             screenHeight - Pescoco.Y));
                        esp.DrawLine(SkeletonColor, 2,
                                     Vector2((screenWidth - (screenWidth - Pescoco.X) +
                                              linex), screenHeight - Pescoco.Y),
                                     Vector2((screenWidth - (screenWidth - player.Hip.X)),
                                             screenHeight - player.Hip.Y));
                        esp.DrawLine(SkeletonColor, 2,
                                     Vector2((screenWidth - (screenWidth - player.Hip.X) + linex),
                                             screenHeight - player.Hip.Y),
                                     Vector2((screenWidth - (screenWidth - PeDireito.X)),
                                             screenHeight - PeDireito.Y));
                        esp.DrawLine(SkeletonColor, 2,
                                     Vector2((screenWidth - (screenWidth - player.Hip.X) + linex),
                                             screenHeight - player.Hip.Y),
                                     Vector2((screenWidth - (screenWidth - PeEsquerdo.X)),
                                             screenHeight - PeEsquerdo.Y));
                        esp.DrawLine(SkeletonColor, 2,
                                     Vector2((screenWidth - (screenWidth - Sholder1.X) + linex),
                                             screenHeight - Sholder1.Y),
                                     Vector2((screenWidth - (screenWidth - player.MaoDireita.X)),
                                             screenHeight - player.MaoDireita.Y));
						esp.DrawLine(SkeletonColor, 2,
                                     Vector2((screenWidth - (screenWidth - Pescoco.X) + linex),
                                             screenHeight - Pescoco.Y),
                                     Vector2((screenWidth - (screenWidth - player.Sholder1.X)),
                                             screenHeight - player.Sholder1.Y));
                        esp.DrawLine(SkeletonColor, 2,
                                     Vector2((screenWidth - (screenWidth - Sholder2.X) + linex),
                                             screenHeight - Sholder2.Y),
                                     Vector2((screenWidth - (screenWidth - player.MaoEsquerda.X)),
                                             screenHeight - player.MaoEsquerda.Y));
						esp.DrawLine(SkeletonColor, 2,
                                     Vector2((screenWidth - (screenWidth - Pescoco.X) + linex),
                                             screenHeight - Pescoco.Y),
                                     Vector2((screenWidth - (screenWidth - player.Sholder2.X)),
                                             screenHeight - player.Sholder2.Y));
                       

                   }
                }
              }
           }
        }
     }
extern "C"
JNIEXPORT void JNICALL
Java_com_Loader_DarkSide_Floatingdarkside_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}
void *KLoad(void *arg) {
    while (true) {
        if (getRealOffset(0) != 0) {
            if (active) {
                HOOK(0xA1D620, _LateUpdate, LateUpdate);

                pthread_exit(0);
            }
        }
        sleep(1);
    }
    return NULL;
}

bool (*orig_ghost)(void* _this, int value);
bool _ghost(void* _this, int value){
    if (_this != NULL){
        if (ghost || teleKill){
            return false;
        }
    }
    return orig_ghost(_this, value);
}

bool (*GravityTrue)(void* _this);
bool _GravityTrue(void* _this) {
    if (Gravity) {
        return true;
    }
    return GravityTrue(_this);
}
float (*NegativeGravity)(int* _this);
float _NegativeGravity(int* _this) {
    if (NegativeGravity != NULL) {
        if (Gravity) {
            return -500.0f;
        }
    }
    return NegativeGravity(_this);
}
bool (*Prancha)(void* _this);
bool _Prancha(void* _this) {
    if (Gravity) {
        return true;
    }
    return Prancha(_this);
}
bool (*FlyAltura)(void* _this);
bool _FlyAltura(void* _this) {
    if (FlyHeight) {
        return true;
    }
    return FlyAltura(_this);
}
bool (*AutoRevive)(void* _this);
bool _AutoRevive(void* _this) {
    if (autoRevive) {
        return true;
    }
    return AutoRevive(_this);
}
bool(*BypassESP)(void* _this);
bool _BypassESP(void* _this) {
    return true;
}
bool(*BypassESP1)(void* _this);
bool _BypassESP1(void* _this) {
    return true;
}
bool(*BypassESP2)(void* _this);
bool _BypassESP2(void* _this) {
    return true;
}
bool(*BypassESP3)(void* _this);
bool _BypassESP3(void* _this) {
    return true;
}
bool(*BypassESP4)(void* _this);
bool _BypassESP4(void* _this) {
    return true;
}
bool(*BypassESP5)(void* _this);
bool _BypassESP5(void* _this) {
    return true;
}
bool(*BypassESP6)(void* _this);
bool _BypassESP6(void* _this) {
    return true;
}
bool(*BypassESP7)(void* _this);
bool _BypassESP7(void* _this) {
    return true;
}
bool(*BypassESP8)(void* _this);
bool _BypassESP8(void* _this) {
    return true;
}
bool(*BypassESP9)(void* _this);
bool _BypassESP9(void* _this) {
    return true;
}
bool(*BypassESP10)(void* _this);
bool _BypassESP10(void* _this) {
    return true;
}
bool(*BypassESP11)(void* _this);
bool _BypassESP11(void* _this) {
    return true;
}
bool(*BypassESP12)(void* _this);
bool _BypassESP12(void* _this) {
    return true;
}
bool(*BypassESP13)(void* _this);
bool _BypassESP13(void* _this) {
    return true;
}
bool(*BypassESP14)(void* _this);
bool _BypassESP14(void* _this) {
    return true;
}
bool(*BypassESP15)(void* _this);
bool _BypassESP15(void* _this) {
    return true;
}
bool(*SetUserInfo)(void* _this);
bool _SetUserInfo(void* _this){
	if (SetUserInfo != NULL) { 
	return true; 
	   } 
	} 
bool(*AnoSDKloct)(void* _this);
bool _AnoSDKloct(void* _this){ 
   if (AnoSDKloct != NULL) { 
    return true;
       } 
    }
bool(*AnoSDKInit)(void* _this);
bool _AnoSDKInit(void* _this){ 
   if (AnoSDKInit != NULL) { 
   return true; 
    } 
  }
bool(*OnRecVData)(void* _this); 
bool _OnRecVData(void* _this){
	if (OnRecVData != NULL) { 
	return true;
	}
 } 
bool(*DelReportData)(void* _this);
bool _DelReportData(void* _this){
	if (DelReportData != NULL) {
		return true;
		} 
	 } 
bool(*AnoSDKOnPause)(void* _this);
bool _AnoSDKOnPause(void* _this){
	if (AnoSDKOnPause != NULL) {
		return true;
		} 
	 }
bool(*GetReportData)(void* _this);
bool _GetReportData(void* _this){
	if (GetReportData != NULL) {
		return true;
		} 
	 }
bool(*AnoSDKForExport)(void* _this);
bool _AnoSDKForExport(void* _this){
	if (AnoSDKForExport != NULL) {
		return true;
	    } 
	 }
bool(*GetReportData2)(void* _this);
bool _GetReportData2(void* _this){
	if (GetReportData2 != NULL) {
		return true;
		}
	 } 
bool(*RegistInfoListener)(void* _this);
bool _RegistInfoListener(void* _this){ 
    if (RegistInfoListener != NULL) { 
        return true;
		}
	 } 
bool(*GetReportData3)(void* _this);
bool _GetReportData3(void* _this){
	if (GetReportData3 != NULL) { 
	    return true;
		}
	 } 
bool(*OnRecVSignature)(void* _this);
bool _OnRecVSignature(void* _this){ 
    if (OnRecVSignature != NULL) { 
	    return true; 
		}
	 } 
bool(*AnoSDKOnResume)(void* _this);
bool _AnoSDKOnResume(void* _this){
	if (AnoSDKOnResume != NULL) {
		return true;
		}
	 } 
bool(*GetDeletReportData3)(void* _this);
bool _GetDeletReportData3(void* _this){ 
      if (GetDeletReportData3 != NULL) { 
	      return true;
		  }
	 } 
bool(*initializeRank)(void* _this);
bool _InitializeRank(void* _this) {
	return true;
	}
bool(*acharpartida)(void* _this);
bool _acharpartida(void* _this){
	return false;
	}
bool(*RefreshNewPlayerSigninState)(void* _this);
bool _RefreshNewPlayerSigninState(void* _this){
	return true;
	}
bool(*black)(void* _this);
bool _black(void* _this){
	return false;
	}
bool(*get_DebugSkipRoomCheck)(void* _this);
bool _get_DebugSkipRoomCheck(void* _this){
	return false;
	}
bool(*OnNewPlayerSigninClick)(void* _this);
bool _OnNewPlayerSigninClick(void* _this){
	return false;
	}
void(*acharpartida0)(void* _this);
void _acharpartida0(void* _this){
	return;
	}
void(*acharpartida3)(void* _this);
void _acharpartida3(void* _this){
	return;
	}
void (*Log)(void *_thiz);
void _Log(void *_thiz){
	if (_thiz) {
	 return;
	  }
     Log(_thiz);
   } 

void(*entermatch)(void* _this);
void _entermatch(void* _this){
    if (entermatch != NULL) {
        return;
    }
    return entermatch(_this);
}

void(*entermatch2)(void* _this);
void _entermatch2(void* _this){
    if (entermatch2 != NULL) {
        return;
    }
    return entermatch2(_this);
}

void(*entermatch3)(void* _this);
void _entermatch3(void* _this){
    if (entermatch3 != NULL) {
        return;
    }
    return entermatch3(_this);
}

void(*t1)(void* _this);
void _t1(void* _this){
    if (t1 != NULL) {
        return true;
    }
    return t1(_this);
}

void(*t2)(void* _this);
void _t2(void* _this){
    if (t2 != NULL) {
        return true;
    }
    return t2(_this);
}

void(*t3)(void* _this);
void _t3(void* _this){
    if (t3 != NULL) {
        return true;
    }
    return t3(_this);
}

void(*t4)(void* _this);
void _t4(void* _this){
    if (t4 != NULL) {
        return true;
    }
    return t4(_this);
}

void(*t10)(void* _this);
void _t10(void* _this){
    if (t10 != NULL) {
        return true;
    }
    return t10(_this);
}

void(*t11)(void* _this);
void _t11(void* _this){
    if (t11 != NULL) {
        return true;
    }
    return t11(_this);
}

void(*noblack)(void* _this);
void _noblack(void* _this){
    if (noblack != NULL) {
        return;
    }
    return noblack(_this);
}

void *hack_thread(void *) {
    LOGI("Loading...");

    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid());
    
    BAPANFFpatches.TeletransportarCarro = MemoryPatch("libil2cpp.so", 0x2ED6F98, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.MedKitRunning = MemoryPatch("libil2cpp.so", 0x18637F8, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.MedKitRunning2 = MemoryPatch("libil2cpp.so", 0xA1CF64, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.NoRecoil = MemoryPatch("libil2cpp.so", 0xA83794, "\x03\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.Corridinha50x = MemoryPatch("libil2cpp.so", 0xA2229C, "\xB2\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.Speed = MemoryPatch("libil2cpp.so", 0xA2229C, "\x81\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.Speed2x = MemoryPatch("libil2cpp.so", 0xA2229C, "\x82\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.Speed3x = MemoryPatch("libil2cpp.so", 0xA2229C, "\x83\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.Speed4x = MemoryPatch("libil2cpp.so", 0xA2229C, "\x84\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    BAPANFFpatches.Speed5x = MemoryPatch("libil2cpp.so", 0xA2229C, "\x85\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
	BAPANFFpatches.Wallhack = MemoryPatch("libunity.so",0xEE813C, "\x4A\xEB\x8F\xBF\x00\x00\xA0\xE3", 8);
	BAPANFFpatches.Speedfire = MemoryPatch("libil2cpp.so", 0x1AE978C , "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
	
	MSHookFunction((void*)getRealOffset(0x158AD98), (void*)_entermatch, (void**)&entermatch); //1.59
    MSHookFunction((void*)getRealOffset(0x158E95C), (void*)_entermatch, (void**)&entermatch); //1.59
    MSHookFunction((void*)getRealOffset(0x158F994), (void*)_entermatch, (void**)&entermatch); //1.59
    MSHookFunction((void*)getRealOffset(0x2A70BC4), (void*)_entermatch, (void**)&entermatch); //1.59
    MSHookFunction((void*)getRealOffset(0x2FAE6E0), (void*)_entermatch2, (void**)&entermatch2); //1.59
    MSHookFunction((void*)getRealOffset(0x27E5EA4), (void*)_entermatch3, (void**)&entermatch3); //1.59
    MSHookFunction((void*)getRealOffset(0x27E5DC0), (void*)_noblack, (void**)&noblack); //1.59
	MSHookFunction((void*)getRealOffset(0x1A61480), (void*)_t1, (void**)&t1);
    MSHookFunction((void*)getRealOffset(0x1A614B4), (void*)_t2, (void**)&t2);
    MSHookFunction((void*)getRealOffset(0x1A61728), (void*)_t3, (void**)&t3);
    MSHookFunction((void*)getRealOffset(0x1A61728), (void*)_t4, (void**)&t4);
    MSHookFunction((void*)getRealOffset(0x2E4FB98), (void*)_t10, (void**)&t10);
    MSHookFunction((void*)getRealOffset(0x25828BC), (void*)_t11, (void**)&t11);
    MSHookFunction((void*)getRealOffset(0x176671C), (void*)_acharpartida, (void**)&acharpartida);
    MSHookFunction((void*)getRealOffset(0x158E95C), (void*)_acharpartida, (void**)&acharpartida); 
    MSHookFunction((void*)getRealOffset(0x158F994), (void*)_acharpartida, (void**)&acharpartida);
    MSHookFunction((void*)getRealOffset(0x2A70BC4), (void*)_acharpartida, (void**)&acharpartida);
    MSHookFunction((void*)getRealOffset(0x2B312E0), (void*)_acharpartida0, (void**)&acharpartida0);
    MSHookFunction((void*)getRealOffset(0x133C9AC), (void*)_acharpartida0, (void**)&acharpartida0);
    MSHookFunction((void*)getRealOffset(0x27E5EA4), (void*)_acharpartida3, (void**)&acharpartida3); 
    MSHookFunction((void*)getRealOffset(0x1344F38), (void*)_acharpartida3, (void**)&acharpartida3);
	
	HOOK(0x15290E4,_get_DebugSkipRoomCheck, get_DebugSkipRoomCheck); // 13 //1.59// EAccount.NewbieChoice 
	HOOK(0xD64970,_OnNewPlayerSigninClick, OnNewPlayerSigninClick); // 11 //1.59 //OnNewPlayerSigninClick 
	HOOK(0x121A28C,_OnNewPlayerSigninClick, OnNewPlayerSigninClick); // 12 //1.59 //NewPlayerSignin(int signinIndex) { } 
	HOOK(0x121ACC8,_OnNewPlayerSigninClick, OnNewPlayerSigninClick); // 12 //1.59//get_IsNewPlayer 
	HOOK(0x12198D4,_OnNewPlayerSigninClick, OnNewPlayerSigninClick); // 13 //1.59// get_HaveNewSignin() { } 
	HOOK(0xD4F71C,_OnNewPlayerSigninClick, OnNewPlayerSigninClick); // 13 //1.59// private void FirstMatchProcess(object[] args) { } 
    HOOK(0x158AD98,_acharpartida, acharpartida);//
	HOOK(0x158E95C,_acharpartida, acharpartida);//
	HOOK(0x158F994,_acharpartida, acharpartida);//
	HOOK(0x28F7314,_acharpartida, acharpartida);// 
	HOOK(0x2A70BC4,_acharpartida0, acharpartida0);// 
	HOOK(0x133C9AC,_acharpartida0, acharpartida0);// 
	HOOK(0x27E5EA4,_acharpartida3, acharpartida3);// 
	HOOK(0x1344F38,_acharpartida3, acharpartida3); 
	HOOK(0x2E4A344,_Log, Log);
	HOOK(0xD55618,_RefreshNewPlayerSigninState, RefreshNewPlayerSigninState); // 11 //1.59 //private void CheckLobbyExtraAdsTips() { } 
	HOOK(0xD5CA3C,_RefreshNewPlayerSigninState, RefreshNewPlayerSigninState); // 12 //1.59 //private bool CheckPlayerLimits(zTfbhtW groupMode, bool showTips = True) 
	HOOK(0xD5E9E4,_RefreshNewPlayerSigninState, RefreshNewPlayerSigninState); // 12 //1.59//private void OnOnPveDifficultyChanged(object[] param) { } 
	HOOK(0xD4CA48,_RefreshNewPlayerSigninState, RefreshNewPlayerSigninState); // 13 //1.59//  private void RefreshNewPlayerSigninState() { }. 
	HOOK(0x2DEA5F0,_black, black); // 11 //1.59/public uint get_ban_expire_duration() { }//public class BlacklistRes//ctor+14C
	HOOK(0x2DEA5C8,_black, black); // 12 //1.59 //get_ban_time //public class BlacklistRes//ctor+124
	HOOK(0x2DEA3F5,_black, black); // 12 //1.59//public EAccount.BlacklistOpType get_ban_type() { } //BlacklistOpReq //ctor +109 
	HOOK(0x2DEA5E0,_black, black); // 11 //1.59 //public static void SendEventLog(string eventType, EventLogger.EventLoggerBase payload 
	HOOK(0x2DEA598,_black, black); // 12 //1.59 //SendGameLagLog 
	HOOK(0x2DEA4AC,_black, black); // 12 //1.59//SendGameMemoryLog 
	HOOK(0x2B56C4C,_black, black); // 13 //1.59// public static void SendNetworkEventLog(string eventType, object payload); 
	HOOK(0x24512F0,_black, black); // 14 //1.59 //public static void SendLogObserver(). 
	HOOK(0x2B567C4,_black, black); // 15 //1.59 //public static void LogAndroidApplicationDetection(List1<int> installedIDs);.
	HOOK(0x2B56138,_black, black); // 16 //1.59 //public static CMOD_OPT LogEnterGame()
	HOOK(0x2B56148,_black, black); // 11 //1.59 //public static void Loggamememory 
	HOOK(0x2D48B20,_black, black); // 12 //1.59 //public static void LogScanIAPInventoryResult 
	HOOK(0x17CD020,_black, black); // 12 //1.59//public static void StartObserver(int mode) {
	
	
    HOOK(0xA4ED98, _GravityTrue, GravityTrue);
    HOOK(0x9EC170, _NegativeGravity, NegativeGravity);
    HOOK(0x9F81A0, _Prancha, Prancha);
    HOOK(0xA54CD8, _FlyAltura,FlyAltura);
	HOOK(0x177CD00, _AutoRevive, AutoRevive);
    HOOK(0x16645B8, GrenadeLine_Update, _GrenadeLine_Update);
    HOOK(0x2C3014C, _BypassESP, BypassESP);
    HOOK(0x266BD8C, _BypassESP1, BypassESP1);
    HOOK(0x2CDEF04, _BypassESP2, BypassESP2);
    HOOK(0x2CDEFB4, _BypassESP3, BypassESP3);
    HOOK(0x15B3600, _BypassESP4, BypassESP4);
    HOOK(0x266D2E0, _BypassESP5, BypassESP5);
    HOOK(0x266D684, _BypassESP6, BypassESP6);
    HOOK(0x266D5D4, _BypassESP7, BypassESP7);
    HOOK(0x2C97084, _BypassESP8, BypassESP8);
    HOOK(0x266BF30, _BypassESP9, BypassESP9);
    HOOK(0x266D520, _BypassESP10, BypassESP10);
    HOOK(0x2629F98, _BypassESP11, BypassESP11);
    HOOK(0x26254C8, _BypassESP12, BypassESP12);
    HOOK(0x261C98C, _BypassESP13, BypassESP13);
    HOOK(0x2625278, _BypassESP14, BypassESP14);
    HOOK(0x2625038, _BypassESP15, BypassESP15);
    HOOK(0x2429044, _ghost, orig_ghost);
    return NULL;

}

void *bypass_safe (void *) { 

      ProcMap il2cppMap24;
	  do {
		  il2cppMap24 = KittyMemory::getLibraryMap("libanogs.so");
    sleep(1); } while(!il2cppMap24.isValid()); 
	
HOOK ( 0x121E0, _SetUserInfo,SetUserInfo); //SetUserInfo 
HOOK ( 0x122C8, _AnoSDKloct,AnoSDKloct ); //AnoSDKloct
HOOK ( 0x121C4, _AnoSDKInit,AnoSDKInit); //AnoSDKInit
HOOK ( 0x12288 ,_OnRecVData,OnRecVData ); //OnRecVData
HOOK( 0x12274, _DelReportData,DelReportData); //DelReportData 
HOOK ( 0x12230 , _AnoSDKOnPause,AnoSDKOnPause); //AnoSDKOnPause
HOOK ( 0x12264 , _GetReportData,GetReportData); //GetReportData 
HOOK( 0x12328 , _AnoSDKForExport,AnoSDKForExport); //AnoSDKForExport
HOOK ( 0x122DC , _GetReportData2,GetReportData2); //GetReportData2
HOOK( 0x12304 ,_RegistInfoListener,RegistInfoListener); //RegistInfoListener 
HOOK ( 0x122E4, _GetReportData3,GetReportData3); //GetReportData3 
HOOK ( 0x122F8 ,_OnRecVSignature,OnRecVSignature); //OnRecVSignature 
HOOK( 0x12248 , _AnoSDKOnResume,AnoSDKOnResume); //AnoSDKOnResume 
HOOK( 0x122F0 , _GetDeletReportData3,GetDeletReportData3); //GetDeletReportData3 
return NULL;

}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    if (!launched) {

        launched = true;

        pthread_t ptid;
        pthread_create(&ptid, NULL, hack_thread, NULL);
        pthread_t ptid2;
        pthread_create(&ptid2, NULL, KLoad, NULL);

    }
    return JNI_VERSION_1_6;

}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {
}





