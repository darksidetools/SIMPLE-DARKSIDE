package com.Loader.DarkSide;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.annotation.SuppressLint;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import java.io.BufferedReader;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.graphics.Canvas;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.view.ViewGroup.MarginLayoutParams;
import android.graphics.Color;
import android.view.WindowManager.LayoutParams;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import com.Loader.DarkSide.Espdarkside;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import android.widget.Toast;
import android.text.TextUtils;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Floatingdarkside extends Service {
    public View mFloatingView;
    private Button close;

    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    private WindowManager.LayoutParams espParams;
    private Espdarkside overlayView;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private ImageView startimage2;
    private LinearLayout view1;
    private LinearLayout view2;
    private LinearLayout Btns;
    private LinearLayout Btns2;
    private final int MENU_WIDTH = 230;
    private final int MENU_HEIGHT = 230;
    private native void ContexL();

    private AlertDialog alert;
    private EditText edittextvalue;

    private static final String TAG = "Mod Menu";

    //initialize methods from the native librar
    public static native void DrawOn(Espdarkside espView, Canvas canvas);

    private native String Title();

    //private native String Conexao();

    private native String Heading();

    //   private native String Icon();

    private native String IconWebViewData();

    private native boolean EnableSounds();

    private native int IconSize();

    public native void Changes(int feature, int value);
	

    private native String[] getdarkList();

    public WindowManager windowManager;

    private int getLayoutType() {
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_TOAST;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }
        return LAYOUT_FLAG;
    }

    private void DrawCanvas() {
     this.espParams = new WindowManager.LayoutParams(
     WindowManager.LayoutParams.MATCH_PARENT,
     WindowManager.LayoutParams.MATCH_PARENT,
     getLayoutType(),
     WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
     PixelFormat.TRANSLUCENT);
     espParams.gravity = Gravity.TOP | Gravity.START;
     espParams.x = 0;
     espParams.y = 100;

     windowManager.addView(this.overlayView, this.espParams);
     }
     

    private native boolean Parametros();
    private void Nhwie(String ctx) {System.loadLibrary(ctx);}
    String Parametros18;
    private void lLl() {if (Parametros()) {IsParametros();}}


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    //When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
        super.onCreate();
        this.overlayView = new Espdarkside((Context)this);
        System.loadLibrary("unily");
        this.overlayView = new Espdarkside(this);
        windowManager = (WindowManager) this.getSystemService(Context.WINDOW_SERVICE);
        DrawCanvas();
        initFloating();
        initAlertDiag();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    Thread();
                    handler.postDelayed(this, 10);
                }
            });
    }

    void Destroy() {
        View view = this.mFloatingView;
        if (view != null) {
            this.mWindowManager.removeView(view);
            this.mFloatingView = null;
        }
        Espdarkside espView = this.overlayView;
        if (espView != null) {
            this.mWindowManager.removeView(espView);
            this.overlayView = null;
        }
    }
    int TextSize = 14;
    boolean ValorTF = false;
    private void IsParametros() {if (0 == TextSize) {TextSize = 17;} else {TextSize = 27;}if (Parametros()) {Nhwie("MyLibName");initFloating();} else if (!Parametros()) {ValorTF = true;}}



    @SuppressLint("Range")
    private boolean isNetworkConected() {
        return ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo() != null;
    }
    //Here we write the code for our Menu
    private void initFloating() {
        rootFrame = new FrameLayout(getBaseContext()); // Global markup
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
        Btns = new LinearLayout(getBaseContext());
        Btns2 = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)

        RelativeLayout relativeLayout = new RelativeLayout((Context)this);
        relativeLayout.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(3, 0, 3, 3);
        relativeLayout.setVerticalGravity(16);

        LinearLayout.LayoutParams ggg = new LinearLayout.LayoutParams(150, 40);
        close = new Button(this);
        close.setBackgroundColor(Color.parseColor("#000000"));
        close.setText("CLOSE");
        close.setTextColor(Color.parseColor("WHITE"));
        close.setLayoutParams(new RelativeLayout.LayoutParams(170, dp(35)));
        close.setTypeface(null, Typeface.BOLD_ITALIC);
        android.graphics.drawable.GradientDrawable BEBCBGD = new android.graphics.drawable.GradientDrawable();
        int BEBCBGDADD[] = new int[]{ Color.argb(255,255,0,0), Color.argb(255,255,0,0) };
        BEBCBGD.setColors(BEBCBGDADD);
        BEBCBGD.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TR_BL);
       // BEBCBGD.setCornerRadii(new float[] { 0, 0, 96, 96, 0, 0, 0, 0 });
        android.graphics.drawable.RippleDrawable BEBCBGD_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(84,0,255,255)}), BEBCBGD, null);
        close.setBackground(BEBCBGD_RE);
        if(Build.VERSION.SDK_INT >= 21) { close.setElevation(100f); }

        //********** Hide button **********
        Button kill = new Button(this);
        kill.setBackgroundColor(Color.parseColor("#00000000"));
        kill.setText(Html.fromHtml("<a href=\"https://t.me/KTM_269\"> * Click Here *"));
        kill.setTextColor(Color.parseColor("#ff0000"));
        kill.setGravity(Gravity.RIGHT);
        kill.setShadowLayer(12.0f, 0.0f, 0.0f, -16711681);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);

        //********* Linear Ps2 **********

        LinearLayout PSLayoutTop = new LinearLayout(this);
        PSLayoutTop.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        PSLayoutTop.setOrientation(2);

        //********* Linear Ps **********

        LinearLayout PSLayout = new LinearLayout(this);
        PSLayout.setGravity(Gravity.CENTER);
        PSLayout.setLayoutParams(new LinearLayout.LayoutParams(layoutParams.FILL_PARENT, -1));

        //********** FREE FIRE *********

        TextView nomeJogoVersao = new TextView(this);
        nomeJogoVersao.setText("Free Fire v1.59.5");
        nomeJogoVersao.setTextColor(Color.WHITE);
        nomeJogoVersao.setTextSize(14.0f);
        nomeJogoVersao.setHeight(60);
        nomeJogoVersao.setGravity(17);
        nomeJogoVersao.setTypeface(Typeface.MONOSPACE);
        //nomeJogoVersao.setLayoutParams(layoutParams2);


        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        //  byte[] decode = Base64.decode(Icon(), 0);
        //  startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);

        
     /*   startimage2 = new ImageView(getBaseContext());
        startimage2.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        startimage2.getLayoutParams().height = 150;
        startimage2.getLayoutParams().width = 150;
        startimage2.requestLayout();
        startimage2.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode2 = Base64.decode(Icon(), 0);
        startimage2.setImageBitmap(BitmapFactory.decodeByteArray(decode2, 0, decode2.length));
        startimage2.setImageAlpha(200);
        */
        
        mExpanded = new LinearLayout(this); // Menu markup (when the menu is expanded)
        mExpanded.setVisibility(View.GONE);
        //mExpanded.setBackgroundColor(MENU_BG_COLOR);
        //  mExpanded.setAlpha(0.77f);
        mExpanded.setGravity(Gravity.CENTER);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(230), -2));
        mExpanded.setPadding(0, 0, 0, 0);
        mExpanded.setBackgroundColor(Color.argb(255,15,169,255));
        android.graphics.drawable.GradientDrawable GIDDGID = new android.graphics.drawable.GradientDrawable();
        int GIDDGIDADD[] = new int[]{ Color.argb(255,255,0,0), Color.argb(255,0,0,0) };
        GIDDGID.setColors(GIDDGIDADD);
        GIDDGID.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TL_BR);
        GIDDGID.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
        android.graphics.drawable.RippleDrawable GIDDGID_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(84,0,255,255)}), GIDDGID, null);
        mExpanded.setBackground(GIDDGID_RE);
        if(Build.VERSION.SDK_INT >= 21) { mExpanded.setElevation(100f); }

        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(150)));
        scrollView.setBackgroundColor(Color.BLACK);


        // e//sse.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        view1.setBackgroundColor(Color.parseColor("#121111"));
        //  this.hr = new LinearLayout.LayoutParams(-1, -1);
        //  this.hr.setMargins(0, 0, 0, 5);
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setPadding(5, 5, 5, 5);
        patches.setOrientation(LinearLayout.VERTICAL);

        view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        view2.setBackgroundColor(Color.parseColor("#414040"));
        view2.setPadding(0, 0, 0, 10);
        this.mButtonPanel.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));

        this.Btns2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.Btns2.setBackgroundColor(Color.BLACK);
        this.Btns2.setGravity(17);
        this.Btns2.setPadding(0, 0, 5, 0);
        this.Btns2.setOrientation(LinearLayout.HORIZONTAL);



        //********* Linear ButtonClose **********

        this.Btns.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.Btns.setBackgroundColor(Color.BLACK);
        this.Btns.setGravity(6);
        this.Btns.setPadding(0, 0, 5, 0);
        this.Btns.setOrientation(LinearLayout.HORIZONTAL);

        TextView Icon = new TextView(getBaseContext());
        Icon.setText("DARK-SIDE");
        Icon.setTypeface(null, Typeface.BOLD_ITALIC);
        Icon.setTextColor(Color.RED);
        Icon.setBackgroundColor(Color.TRANSPARENT);
        Icon.setTextSize(15.0f);
        //textView.setGravity(17);

        TextView textView = new TextView(getBaseContext());
        textView.setText(Html.fromHtml("DARKSIDE - VIP"));
        textView.setTextColor(Color.WHITE);
        textView.setBackgroundColor(Color.TRANSPARENT);
        textView.setTypeface(null, Typeface.BOLD_ITALIC);
        textView.setTextSize(18.0f);
        textView.setGravity(17);
        textView.setPadding(0, 15, 0, 0);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -1);
        layoutParams2.gravity = 17;


        //TextView2
        TextView textView2 = new TextView(getBaseContext());
        textView2.setText(Html.fromHtml("<font color='WHITE'>Username: </font>" )); 
        textView2.setTextSize(12.0f);
        textView2.setPadding(5, 0, 0, 1);
        textView2.setTypeface(Typeface.MONOSPACE);
        textView2.setGravity(Gravity.LEFT);
        textView2.setTextColor(Color.WHITE);

        TextView textView3 = new TextView(getBaseContext());
        textView3.setText(Html.fromHtml("<font color='WHITE'>Game Version: </font> Free Fire 1.60.2")); 
        textView3.setTextSize(12.0f);
        textView3.setPadding(5, 0, 0, 5);
        textView3.setTypeface(Typeface.MONOSPACE);
        textView3.setGravity(Gravity.LEFT);
        textView3.setTextColor(Color.WHITE);

		TextView textView4 = new TextView(getBaseContext());
        textView4.setText(Html.fromHtml("<font color='WHITE'>Mod Version: </font> V2 Rage")); 
        textView4.setTextSize(12.0f);
        textView4.setPadding(5, 0, 0, 5);
        textView4.setTypeface(Typeface.MONOSPACE);
        textView4.setGravity(Gravity.LEFT);
        textView4.setTextColor(Color.WHITE);
		
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams5.gravity = 17;
        textView.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
     //   textView2.setLayoutParams((ViewGroup.LayoutParams)layoutParams5);
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);

        if (IconWebViewData() != null) {
            mCollapsed.addView(view1);
        } else {
            mCollapsed.addView(Icon);
        }

        mExpanded.addView(PSLayoutTop);
       // PSLayoutTop.addView(startimage2);
        PSLayoutTop.addView(PSLayout);
        //mCollapsed.addView(closeimage);
        // mCollapsed.addView(startimage);
        PSLayout.addView(textView);
      //  mExpanded.addView(textView2);
        mExpanded.addView(textView3);
        mExpanded.addView(textView4);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
        this.mExpanded.addView(this.Btns2);
        this.Btns2.addView(nomeJogoVersao);
        this.mExpanded.addView(this.Btns);
        this.Btns.addView(this.close);
       // this.Btns.addView(kill);
        mFloatingView = rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);
        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        view2.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);
        CreateMenuList();
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);

                            //  Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    public void checkSerial(String string2) {
        if (this.isNetworkConected() && string2 != null) {
            this.CreateMenuList();
            return;
        }
        Toast.makeText((Context)this.getBaseContext(), (CharSequence)"MOD MENU DESATIVADO", (int)1).show();
    }
    protected /* varargs */ String doInBackground(String ... arrstring) {
        String string2 = null;
        try {
            String string3;
            BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(((HttpURLConnection)new URL(arrstring[0]).openConnection()).getInputStream()));
            while ((string3 = bufferedReader.readLine()) != null) {
                string2 = string3;
            }
            return string2;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return string2;
        }
    }

    protected void onPostExecute(String string2) {
        Floatingdarkside.this.checkSerial(string2);
    }


    //Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.GONE);
                    view3.setVisibility(View.VISIBLE);
                }
            });

        close.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.VISIBLE);
                    view2.setAlpha(0.95f);
                    view3.setVisibility(View.GONE);
                    //Toast.makeText(view.getContext(), "BERLIN ModZ", Toast.LENGTH_LONG).show();

                    //Log.i("LGL", "Close");
                }
            });
    }

    public final void CreateMenuList() {
        String[] listFT = getdarkList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("Toggle_")) {

                addSwitch(str.replace("Toggle_", ""), new InterfaceBool() {
                        public void OnWrite(boolean z) {
                            Changes(feature, 0);
                        }
                    });
            } else if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                            //Toast.makeText(getBaseContext(), "ACTIVATED", Toast.LENGTH_LONG).show();
                        }
                    });
            } else if (str.contains("SeekBarSpot_")) {
                String[] split = str.split("_");
                addSeekBarSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                            //Toast.makeText(getBaseContext(), "ACTIVATED", Toast.LENGTH_LONG).show();
                        }
                    });
            } else if (str.contains("Category_")) {
                addCategory(str.replace("Category_", ""));
            } else if (str.contains("Button_")) {
                addButton(str.replace("Button_", ""), new InterfaceBtn() {
                        public void OnWrite() {
                            Changes(feature, 0);
                        }
                    });
            } else if (str.contains("Linha_")) {
                String[] split = str.split("_");
                addlinha(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
            } else if (str.contains("Data_")) {
                addTestviw(str.replace("Data_", ""));
            } else if (str.contains("Spinner_")) {
                addSpinner(str.replace("Spinner_", ""), new InterfaceInt() {
                        @Override
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
            } else if (str.contains("InputValue_")) {
                addTextField(str.replace("InputValue_", ""), feature, new InterfaceInt() {
                        @Override
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
            }
        }
    }

    private TextView textView2;
    private String featureNameExt;
    private int featureNum;
    private EditTextValue txtValue;

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }

    private void addTextField(final String featureName, final int feature, final InterfaceInt interInt) {
        RelativeLayout relativeLayout2 = new RelativeLayout(this);
        relativeLayout2.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout2.setPadding(10, 5, 10, 5);
        relativeLayout2.setVerticalGravity(16);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = 1;

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + featureName + ": <font color='#fdd835'>Not set</font></font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        textView.setLayoutParams(layoutParams);

        final TextView textViewRem = new TextView(this);
        textViewRem.setText("MOD MENU TESTE");

        final EditTextValue edittextval = new EditTextValue();

        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);

        Button button2 = new Button(this);
        button2.setLayoutParams(layoutParams2);
        button2.setBackgroundColor(Color.parseColor("#80000000"));
        button2.setText("SET");
        button2.setTextColor(Color.parseColor("#FFFFFF"));
        button2.setGravity(17);
        button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alert.show();
                    textView2 = textView;
                    featureNum = feature;
                    featureNameExt = featureName;
                    txtValue = edittextval;

                    edittextvalue.setText(String.valueOf(edittextval.getValue()));
                }
            });

        relativeLayout2.addView(textView);
        relativeLayout2.addView(button2);
        patches.addView(relativeLayout2);
    }

    private void initAlertDiag() {
        LinearLayout linearLayout1 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout1.setPadding(10, 5, 0, 5);
        linearLayout1.setOrientation(LinearLayout.VERTICAL);
        linearLayout1.setGravity(17);
        linearLayout1.setLayoutParams(layoutParams);
        linearLayout1.setBackgroundColor(Color.parseColor("#80000000"));

        int i = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setBackgroundColor(Color.parseColor("#80000000"));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        frameLayout.addView(linearLayout);

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>Tap OK to apply changes. Tap outside to cancel</font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        textView.setLayoutParams(layoutParams);

        edittextvalue = new EditText(this);
        edittextvalue.setLayoutParams(layoutParams);
        edittextvalue.setMaxLines(1);
        edittextvalue.setWidth(convertDipToPixels(300));
        edittextvalue.setTextColor(Color.parseColor("#93a6ae"));
        edittextvalue.setTextSize(13.0f);
        edittextvalue.setHintTextColor(Color.parseColor("#434d52"));
        edittextvalue.setInputType(InputType.TYPE_CLASS_NUMBER);
        edittextvalue.setKeyListener(DigitsKeyListener.getInstance("0123456789-"));

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(10);
        edittextvalue.setFilters(FilterArray);

        Button button = new Button(this);
        button.setBackgroundColor(Color.parseColor("#80000000"));
        button.setTextColor(Color.parseColor("#D5E3EB"));
        button.setText("OK");
        button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Changes(featureNum, Integer.parseInt(edittextvalue.getText().toString()));
                    txtValue.setValue(Integer.parseInt(edittextvalue.getText().toString()));
                    textView2.setText(Html.fromHtml("<font face='roboto'>" + featureNameExt + ": <font color='#41c300'>" + edittextvalue.getText().toString() + "</font></font>"));
                    alert.dismiss();

                    //interStr.OnWrite(editText.getText().toString());
                }
            });

        alert = new AlertDialog.Builder(this, 2).create();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(alert.getWindow()).setType(i);
        }
        linearLayout1.addView(textView);
        linearLayout1.addView(edittextvalue);
        linearLayout1.addView(button);
        alert.setView(linearLayout1);
    }

    private void addSpinner(String feature, final InterfaceInt interInt) {
        List<String> list = new LinkedList<>(Arrays.asList(feature.split("_")));

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 10, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#80000000"));

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + list.get(0) + ": <font color='#41c300'></font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));

        // Create another LinearLayout as a workaround to use it as a background
        // and to keep the 'down' arrow symbol
        // If spinner had the setBackgroundColor set, there would be no arrow symbol
        LinearLayout linearLayout2 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -1);
        layoutParams2.setMargins(10, 2, 10, 5);
        linearLayout2.setOrientation(LinearLayout.VERTICAL);
        linearLayout2.setGravity(17);
        linearLayout2.setBackgroundColor(Color.parseColor("#80000000"));
        linearLayout2.setLayoutParams(layoutParams2);

        Spinner spinner = new Spinner(this);
        spinner.setPadding(5, 10, 5, 8);
        spinner.setLayoutParams(layoutParams2);
        spinner.getBackground().setColorFilter(1, PorterDuff.Mode.SRC_ATOP); //trick to show white down arrow color
        //Creating the ArrayAdapter instance having the list
        list.remove(0);
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, list);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(aa);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                    ((TextView) parentView.getChildAt(0)).setTextColor(Color.parseColor("#f5f5f5"));
                    interInt.OnWrite(position);

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        linearLayout.addView(textView);
        linearLayout2.addView(spinner);
        patches.addView(linearLayout);
        patches.addView(linearLayout2);
    }

    private void addCategory(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(Color.parseColor("#000000"));
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.RED);
        textView.setTypeface(null, Typeface.BOLD_ITALIC);
        textView.setPadding(10, 5, 0, 5);
        GradientDrawable DCCEEC = new GradientDrawable();
        DCCEEC.setStroke(1, Color.parseColor("#FF0000"));
        textView.setBackground(DCCEEC);
        patches.addView(textView);
    }

    private void addTestviw(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(Color.parseColor("#00000000"));
        textView.setText(text);
        textView.setGravity(11);
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.parseColor("WHITE"));
        textView.setTypeface(null, Typeface.BOLD);
        android.graphics.drawable.GradientDrawable DFFHJFH = new android.graphics.drawable.GradientDrawable();
        int DFFHJFHADD[] = new int[]{ Color.argb(255,232,15,15), Color.argb(255,15,15,15) };
        DFFHJFH.setColors(DFFHJFHADD);
        DFFHJFH.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT);
        DFFHJFH.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
        textView.setBackground(DFFHJFH);
        textView.setPadding(10, 5, 0, 5);
        patches.addView(textView);
    }

    public void addButton(String feature, final InterfaceBtn interfaceBtn) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, dp(38));
        layoutParams.setMargins(0, 5, 0, 5);
        button.setLayoutParams(layoutParams);
        button.setPadding(0, 0, 0, 0);
        button.setTextSize(13.0f);
        button.setGravity(17);

        if (feature.contains("")) {
            feature = feature.replace("", "");
            button.setText(Html.fromHtml("<font face='monospace'>" + feature + "  OFF" + "</font>"));
            button.setBackgroundColor(Color.parseColor("#000000"));
            button.setTextColor(Color.parseColor("WHITE"));
            android.graphics.drawable.GradientDrawable CICFJBE = new android.graphics.drawable.GradientDrawable();
            int CICFJBEADD[] = new int[]{ Color.argb(255,0,0,0), Color.argb(0,0,0,255) };
            CICFJBE.setColors(CICFJBEADD);
            CICFJBE.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT);
            CICFJBE.setCornerRadii(new float[] { 10, 10, 10, 10, 10, 10, 10, 10 });
            CICFJBE.setStroke(3, Color.argb(255,255,15,15));
            button.setBackground(CICFJBE);
            final String feature2 = feature;
            button.setOnClickListener(new View.OnClickListener() {
                    private boolean isActive = true;

                    public void onClick(View v) {
                        interfaceBtn.OnWrite();
                        if (isActive) {
                            button.setText(Html.fromHtml("<font face='monospace'>" + feature2 + "  ON" + "</font>"));
                            button.setBackgroundColor(Color.parseColor("#000000"));
                            button.setTextColor(Color.parseColor("WHITE"));
                            android.graphics.drawable.GradientDrawable BCDJAHA = new android.graphics.drawable.GradientDrawable();
                            int BCDJAHAADD[] = new int[]{ Color.argb(255,232,15,15), Color.argb(255,15,15,15) };
                            BCDJAHA.setColors(BCDJAHAADD);
                            BCDJAHA.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT);
                            BCDJAHA.setCornerRadii(new float[] { 10, 10, 10, 10, 10, 10, 10, 10 });
                            BCDJAHA.setStroke(3, Color.argb(255,255,15,15));
                            button.setBackground(BCDJAHA);
                            isActive = false;
                            return;
                        }
                        button.setText(Html.fromHtml("<font face='monospace'>" + feature2 + "  OFF" + "</font>"));
                        button.setBackgroundColor(Color.parseColor("#000000"));
                        button.setTextColor(Color.parseColor("WHITE"));
                        android.graphics.drawable.GradientDrawable CICFJBE = new android.graphics.drawable.GradientDrawable();
                        int CICFJBEADD[] = new int[]{ Color.argb(255,0,0,0), Color.argb(0,0,0,255) };
                        CICFJBE.setColors(CICFJBEADD);
                        CICFJBE.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT);
                        CICFJBE.setCornerRadii(new float[] { 10, 10, 10, 10, 10, 10, 10, 10 });
                        CICFJBE.setStroke(3, Color.argb(255,255,15,15));
                        button.setBackground(CICFJBE);
                        isActive = true;
                    }
                });

        } else {
            button.setText(feature);
            button.setBackgroundColor(Color.parseColor("#000000"));
            final String feature2 = feature;
            button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        interfaceBtn.OnWrite();
                    }
                });
        }
        patches.addView(button);
    }

    private void addSwitch(String string2, final  InterfaceBool interfaceBool) {
        final GradientDrawable f = new GradientDrawable();
        f.setCornerRadius(50);
        f.setSize(dp(10),dp(1));
        f.setAlpha(50);
        f.setColor(Color.WHITE);
        LinearLayout view4 = new LinearLayout(this);
        view4.setLayoutParams(new LinearLayout.LayoutParams(-1, 2));
        view4.setBackgroundColor(Color.parseColor("#00000000"));
        LinearLayout view5 = new LinearLayout(this);
        view5.setLayoutParams(new LinearLayout.LayoutParams(-1, 2));
        view5.setBackgroundColor(Color.parseColor("#00000000"));


        final Switch sw = new Switch(this);

        GradientDrawable g= new  GradientDrawable();
        g.setSize(50,50);
        g.setShape(1);
        g.setStroke(3,Color.RED);
        g.setColor(Color.BLACK);
        final GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.BLACK);
        gd.setSize(10,4);
        gd.setStroke(2,Color.RED);
        gd.setCornerRadius(100);

        sw.setText(string2);
        sw.setTextColor(Color.WHITE);
        sw.setTypeface(null, Typeface.BOLD_ITALIC);
        sw.setPadding(10, 3, 3, 3);
        sw.setTextSize(15.0f);
        sw.setBackgroundColor(Color.TRANSPARENT);
        sw.setThumbDrawable(g);
        sw.setTrackDrawable(gd);
        sw.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));
        sw.setTypeface(sw.getTypeface(), Typeface.NORMAL);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    interfaceBool.OnWrite(isChecked);
                    if(isChecked) {
                        gd.setColor(Color.RED);

                    } else {
                        gd.setColor(Color.BLACK);
                    }
                }
            });


        patches.addView(sw);
        patches.addView(view5);
    }


    private void addSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);
        linearLayout.setBackgroundColor(Color.parseColor("#000000"));
        linearLayout.getBackground().setAlpha(1);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " <font color='RED'>" + "> OFF" + "</font>"));
        textView.setTypeface(null, Typeface.BOLD_ITALIC);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
        GradientDrawable seekbarCircle = new GradientDrawable();
        seekbarCircle.setShape(1);
        seekbarCircle.setColor(Color.BLACK);
        seekbarCircle.setStroke(dp(2), Color.RED);
        seekbarCircle.setCornerRadius(15.0f);
        seekbarCircle.setSize(dp(17), dp(17));
        seekBar.setThumb(seekbarCircle);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        seekBar.setThumb(seekbarCircle);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);

        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                int l;

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {


                    if (i == 0) {
                        seekBar.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + "<font color='RED'>" + " > OFF" + "</font>"));
                        return;
                    }
                    interInt.OnWrite(i);
                    textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + "<font color='RED'>" + " > " + i + "</font>"));
                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }

    private void addSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);
        linearLayout.setBackgroundColor(Color.parseColor("#000000"));
        linearLayout.getBackground().setAlpha(1);
        linearLayout.setLayoutParams(layoutParams);

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + "<font color='RED'>" + " > OFF" + "</font>"));
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(null, Typeface.BOLD_ITALIC);
        SeekBar seekBar = new SeekBar(this);
        GradientDrawable seekbarCircle = new GradientDrawable();
        seekbarCircle.setShape(1);
        seekbarCircle.setColor(Color.BLACK);
        seekbarCircle.setStroke(dp(2), Color.RED);
        seekbarCircle.setCornerRadius(15.0f);
        seekbarCircle.setSize(dp(17), dp(17));
        seekBar.setThumb(seekbarCircle);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        seekBar.setThumb(seekbarCircle);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);

        final TextView textView2 = textView;
        final SeekBar seekBar2 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar2) {
                }

                public void onStopTrackingTouch(SeekBar seekBar2) {
                }

                int l;

                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    if (i == 0) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + "<font color='RED'>" + " > OFF" + "</b></font>"));
                    } else if (i == 1) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + "<font color='RED'>" + " > HEAD" + "</b></font>"));
                    } else if (i == 2) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + "<font color='RED'>" + " > CHEAST" + "</b></font>"));
                    } else if (i == 3) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + "<font color='RED'>" + " > LEG" + "</b></font>"));
                    }
                    interInt.OnWrite(i);
                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }

    private void addlinha(final String feature, final int prog, int max, final InterfaceInt interInt) {

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#00000000"));
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='White'>" + "White" + "</b></font>"));
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(null, Typeface.BOLD_ITALIC);
        SeekBar seekBar = new SeekBar(this);
        GradientDrawable seekbarCircle = new GradientDrawable();
        seekbarCircle.setShape(1);
        seekbarCircle.setColor(Color.BLACK);
        seekbarCircle.setStroke(dp(2), Color.RED);
        seekbarCircle.setCornerRadius(15.0f);
        seekbarCircle.setSize(dp(17), dp(17));
        seekBar.setThumb(seekbarCircle);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        seekBar.setThumb(seekbarCircle);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);

        final TextView textView2 = textView;
        final SeekBar seekBar2 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar2) {
                }

                public void onStopTrackingTouch(SeekBar seekBar2) {
                }

                int l;

                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    if (i == 0) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='White'>" + "White" + "</b></font>"));
                    } else if (i == 1) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='Green'>" + "Green" + "</b></font>"));
                    } else if (i == 2) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='Black'>" + "Black" + "</b></font>"));

                    } else if (i == 3) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='Blue'>" + "Blue" + "</b></font>"));


                    } else if (i == 4) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='Cyan'>" + "Cyan" + "</b></font>"));


                    } else if (i == 5) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='Purple'>" + "Purple" + "</b></font>"));


                    } else if (i == 6) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='Yellow'>" + "Yellow" + "</b></font>"));


                    } else if (i == 7) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='Red'>" + "Red" + "</b></font>"));
                        
                        
                    } else if (i == 8) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + feature + " > <font color='White'>" + "Random Color" + "</b></font>"));
                        


                    }
                    interInt.OnWrite(i);
                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        this.patches.addView(linearLayout);
    }







    boolean delayed;



    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life
    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

    /* access modifiers changed from: private */
    public void Thread() {
        if (mFloatingView == null) {
            return;
        }
        if (isNotInGame()) {
            mFloatingView.setVisibility(View.INVISIBLE);
        } else {
            mFloatingView.setVisibility(View.VISIBLE);
        }
    }

    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}

