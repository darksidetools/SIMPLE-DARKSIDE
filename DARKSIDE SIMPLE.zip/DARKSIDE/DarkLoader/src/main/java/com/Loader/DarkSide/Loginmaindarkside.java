package com.Loader.DarkSide;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.text.Html;
import android.os.Build;
import android.text.method.LinkMovementMethod;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.UUID;
import android.content.ActivityNotFoundException;
import android.text.Layout;
import android.widget.ActionMenuView.LayoutParams;

public class Loginmaindarkside extends Activity {

	private Stringdarkside Stringdarkside;
	
	public String sGameActivity = "com.Loader.DarkSide.Loginmdarkside";
	
	public static String Username;

	public static String Password;

	private int genDip(float f) {
        return (int) ((f * getResources().getDisplayMetrics().density) + 0.5f);
    }

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		System.loadLibrary("unily");
		Alerta();
		}
	
		public void Alerta() {
        ((TextView) new AlertDialog.Builder(this)
		.setTitle("DARKSIDE OFFICIAL SELLERS")
		.setCancelable(false)
		.setMessage(Html.fromHtml("</p><p>KTM MODDER <a href=\"https://wa.me/qr/742O27L43JIIE1\"> CLICK HERE FOR BUY <p>JIBON GAMING <a href=\"https://wa.me/+8801886-686591\"> CLICK HERE FOR BUY <p>RAHUL MODZ <a href=\"https://wa.me/+919796913153\"> CLICK HERE FOR BUY <p>VKM MOD GAME <a href=\"https://wa.me/+84395719352\"> CLICK HERE FOR BUY <p>LKB MODDER <a href=\"https://wa.me/+916397884898\"> CLICK HERE FOR BUY <p>"))
		.setNegativeButton("CHECK UPDATE", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
					Intent intent = new Intent("android.intent.action.VIEW");
					intent.setData(Uri.parse("http://darkside69.online/#"));
					startActivity(intent);
				    finish();
				}
			})
			.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
                    Login();
                }
            }).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
    }

    private void Login() {
		this.Stringdarkside = Stringdarkside.with(this);

		RelativeLayout mRelativeLayout = new RelativeLayout(this);
        mRelativeLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		mRelativeLayout.setGravity(Gravity.CENTER);

		LinearLayout mLayout = new LinearLayout(this);
        mLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		mLayout.setGravity(Gravity.CENTER);
        mLayout.setBackgroundColor(Color.BLACK);
        mLayout.setPadding(genDip(10.0f), genDip(0.0f), genDip(10.0f), genDip(0.0f));
        mLayout.setOrientation(LinearLayout.VERTICAL);

		LinearLayout mLinearLayout = new LinearLayout(this);
        mLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(genDip(410.0f), -2));

		LinearLayout mLinearLayoutx = new LinearLayout(this);
        mLinearLayoutx.setGravity(Gravity.RIGHT);
		mLinearLayoutx.setPadding(0,0,20,0);
        mLinearLayoutx.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, -1));
        
		
		GradientDrawable gradiente = new GradientDrawable();
		gradiente.setColor(Color.parseColor("#000000"));
        gradiente.setStroke(2, Color.RED);
		gradiente.setCornerRadius(1);
		mLinearLayout.setBackground(gradiente);
		if(Build.VERSION.SDK_INT >= 21) {
			mLinearLayout.setElevation(16f); 
		}

		mLinearLayout.setGravity(Gravity.CENTER);
        mLinearLayout.setPadding(genDip(10.0f), genDip(5.0f), genDip(10.0f), genDip(5.0f));
        mLinearLayout.setOrientation(LinearLayout.VERTICAL);

        LinearLayout mCustom = new LinearLayout(this);
        mCustom.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        mCustom.setOrientation(0);
        mCustom.setGravity(17);


        TextView mTextCustom = new TextView(this);
        mTextCustom.setText("DARKSIDE - VIP");
        mTextCustom.setTextSize(genDip(15.0f));
		mTextCustom.setTextColor(Color.RED);
        mTextCustom.setGravity(1);
        mTextCustom.setPadding(genDip(16.0f), genDip(16.0f), genDip(16.0f), genDip(16.0f));


        mCustom.addView(mTextCustom);


        final EditText mEditUser = new EditText(this);
        mEditUser.setHint("Username");
        mEditUser.setHintTextColor(Color.RED);
        mEditUser.setTextColor(Color.parseColor("#FFFFFF"));
		mEditUser.getBackground().setTintList(ColorStateList.valueOf(Color.parseColor("#ff0000")));
		mEditUser.setText(this.Stringdarkside.read("USER", ""));


        final EditText mEditPass = new EditText(this);
        mEditPass.setHint("Password");
        mEditPass.setHintTextColor(Color.RED);
        mEditPass.setTextColor(Color.parseColor("#FFFFFF"));
        mEditPass.setInputType(129);
		mEditPass.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#ff0000")));
		mEditPass.setText(this.Stringdarkside.read("PASS", ""));


        final CheckBox mBoxViewPass = new CheckBox(this);
        mBoxViewPass.setText("SHOW PASSWORD");
		mBoxViewPass.setPadding(0,0,200,0);
        mBoxViewPass.setTextColor(Color.WHITE);
		mBoxViewPass.setButtonTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));

		mBoxViewPass.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        mBoxViewPass.setText("HIDE PASSWORD  ");
                        mEditPass.setInputType(144);
                    } else {
                        mBoxViewPass.setText("SHOW PASSWORD");
                        mEditPass.setInputType(129);
                    }
                }
            });

        final CheckBox mBoxSave = new CheckBox(this);
        mBoxSave.setText("REMEMBER ME");
        mBoxSave.setTextColor(Color.WHITE);
        mBoxSave.setChecked(true);
		mBoxSave.setButtonTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));

        LinearLayout mLG = new LinearLayout(this);
        mLG.setGravity(Gravity.CENTER);
        mLG.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        mLG.setOrientation(0);
		
		
		

        Button mButtonLogin = new Button(this);
        mButtonLogin.setText("LOGIN");
        mButtonLogin.setTextColor(-1);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(genDip(170.0f), genDip(50.0f));
        layoutParams.setMargins(genDip(6.0f), genDip(6.0f), genDip(6.0f), genDip(6.0f));
        mButtonLogin.setLayoutParams(layoutParams);
        mButtonLogin.setTextColor(-1);

        GradientDrawable mGrad = new GradientDrawable();
        mGrad.setColor(Color.parseColor("#000000"));
        mGrad.setCornerRadii(new float[] { genDip(20.0f), genDip(20.0f), genDip(20.0f), genDip(20.0f), genDip(20.0f), genDip(20.0f), genDip(20.0f), genDip(20.0f) });
		mGrad.setStroke(2, Color.RED);
		
        RippleDrawable Efeito = new RippleDrawable(new ColorStateList(new int[][]{new int[]{}}, new int[] { Color.WHITE  }), mGrad, null);
        mButtonLogin.setBackground(Efeito);



		mLinearLayout.addView(mCustom);
        mLinearLayout.addView(mEditUser);
        mLinearLayout.addView(mEditPass);
        mLinearLayoutx.addView(mBoxViewPass);
		mLinearLayout.addView(mLinearLayoutx);
        mLinearLayoutx.addView(mBoxSave);
        mLinearLayout.addView(mLG);
        mLG.addView(mButtonLogin);

		mRelativeLayout.addView(mLayout);
		mLayout.addView(mLinearLayout);

		setContentView(mRelativeLayout);

		mButtonLogin.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					Loginmaindarkside.this.Username = mEditUser.getText().toString().trim();
					Loginmaindarkside.this.Password = mEditPass.getText().toString().trim();

					if(!Loginmaindarkside.this.Username.isEmpty() && !Loginmaindarkside.this.Password.isEmpty()) {

						if (mBoxSave.isChecked()) {
							Loginmaindarkside.this.Stringdarkside.write("USER", Loginmaindarkside.this.Username);
							Loginmaindarkside.this.Stringdarkside.write("PASS", Loginmaindarkside.this.Password);
						} else {
							Loginmaindarkside.this.Stringdarkside.clear();
						}
						new Loginadarkside(Loginmaindarkside.this).execute(new String[]{Loginmaindarkside.this.Username, Loginmaindarkside.this.Password});
						return;
					}
					Toast.makeText(v.getContext(), "Preencha todos os campos", Toast.LENGTH_LONG).show();
				}
			});

    }
}
