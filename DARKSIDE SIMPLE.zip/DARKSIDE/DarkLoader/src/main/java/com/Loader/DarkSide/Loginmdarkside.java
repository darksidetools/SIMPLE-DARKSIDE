package com.Loader.DarkSide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class Loginmdarkside extends Activity {

    public String GameActivity = "com.dts.freefireth.FFMainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Staticdarkside.StartupDarkSide(this);
        try {
            //Start service
            Loginmdarkside.this.startActivity(new Intent(Loginmdarkside.this, Class.forName(Loginmdarkside.this.GameActivity)));
        } catch (ClassNotFoundException e) {
            //Uncomment this if you are following METHOD 2 of CHANGING FILES
            //Toast.makeText(MainActivity.this, "Error. Game's main activity does not exist", Toast.LENGTH_LONG).show();
            e.printStackTrace();
            return;
        }
    }
}

